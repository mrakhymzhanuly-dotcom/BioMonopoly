import { BoardCell } from '../types/game';
import { TERMS_BY_ID } from './biologyTerms';

function makeTermCell(index: number, termId: string): BoardCell {
  const term = TERMS_BY_ID[termId];
  if (!term) {
    throw new Error(`Unknown termId on board: ${termId}`);
  }
  return {
    index,
    kind: 'term',
    title: term.name,
    termId: term.id,
    category: term.category,
    iconKey: term.iconKey,
  };
}

/**
 * 36-cell square Monopoly-style board (10x10 perimeter, clockwise starting bottom-right):
 * 0: Бастау (Bottom-Right corner)
 * 1..8: Bottom edge (right to left)
 * 9: Түрме (Bottom-Left corner)
 * 10..17: Left edge (bottom to top)
 * 18: Демалыс (Top-Left corner)
 * 19..26: Top edge (left to right)
 * 27: Қызыл аймақ (Top-Right corner)
 * 28..35: Right edge (top to bottom)
 */
export const BOARD_CELLS: BoardCell[] = [
  {
    index: 0,
    kind: 'start',
    title: 'Бастау',
    subtitle: '+100 BioCoin',
    iconKey: 'start',
  },
  makeTermCell(1, 'cell'),
  makeTermCell(2, 'tissue'),
  makeTermCell(3, 'organ'),
  {
    index: 4,
    kind: 'chance',
    title: 'Шанс',
    subtitle: 'Оқиға',
    iconKey: 'chance',
  },
  makeTermCell(5, 'organism'),
  makeTermCell(6, 'chloroplast'),
  makeTermCell(7, 'photosynthesis'),
  makeTermCell(8, 'turgor'),
  {
    index: 9,
    kind: 'jail',
    title: 'Түрме',
    subtitle: 'Зертхана карантині',
    iconKey: 'jail',
  },
  makeTermCell(10, 'gene'),
  makeTermCell(11, 'chromosome'),
  makeTermCell(12, 'dna'),
  {
    index: 13,
    kind: 'red_zone',
    title: 'Қызыл аймақ',
    subtitle: 'Күрделі сұрақ',
    iconKey: 'red_zone',
  },
  makeTermCell(14, 'rna'),
  makeTermCell(15, 'division'),
  makeTermCell(16, 'mitosis'),
  makeTermCell(17, 'meiosis'),
  {
    index: 18,
    kind: 'rest',
    title: 'Демалыс',
    subtitle: 'Ботаника бағы',
    iconKey: 'rest',
  },
  makeTermCell(19, 'protein'),
  makeTermCell(20, 'enzyme'),
  makeTermCell(21, 'metabolism'),
  {
    index: 22,
    kind: 'chance',
    title: 'Шанс',
    subtitle: 'Оқиға',
    iconKey: 'chance',
  },
  makeTermCell(23, 'respiration'),
  makeTermCell(24, 'homeostasis'),
  makeTermCell(25, 'hormone'),
  makeTermCell(26, 'nervous_system'),
  {
    index: 27,
    kind: 'red_zone',
    title: 'Қызыл аймақ',
    subtitle: 'Күрделі сұрақ',
    iconKey: 'red_zone',
  },
  makeTermCell(28, 'erythrocyte'),
  makeTermCell(29, 'leukocyte'),
  makeTermCell(30, 'platelet'),
  makeTermCell(31, 'ecosystem'),
  makeTermCell(32, 'antibody'),
  makeTermCell(33, 'immunity'),
  makeTermCell(34, 'vaccine'),
  makeTermCell(35, 'bacteria'),
];

// Wait: let's make sure 'ecosystem' is also on the board! Let's check:
// We have 36 cells: 4 corners (0,9,18,27) + 4 side specials (4,13,22,31) = 8 special cells, leaving 28 term cells.
// If we have 29 terms, let's replace one side 'chance' or 'term_card' with 'ecosystem' so ALL 29 terms appear on the board!
// Let's check: 4 corners (0: Бастау, 9: Түрме, 18: Демалыс, 27: Термин картасы) + 3 side specials (4: Шанс, 13: Термин картасы, 22: Шанс) = 7 specials + 29 bio terms = 36 cells!
// Let's adjust cell 31 to 'ecosystem' (or put bacteria at 31 and ecosystem at 35)!

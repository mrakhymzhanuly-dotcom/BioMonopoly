import { BiologyTerm, TermCategory } from '../types/game';
import { CELL_GENETICS_TERMS } from './termsCellGenetics';
import { HUMAN_BIOLOGY_TERMS } from './termsHumanBiology';
import { PLANT_ECOLOGY_TERMS } from './termsPlantEcology';

export const ALL_BIOLOGY_TERMS: BiologyTerm[] = [
  ...CELL_GENETICS_TERMS,
  ...HUMAN_BIOLOGY_TERMS,
  ...PLANT_ECOLOGY_TERMS,
];

export const TERMS_BY_ID: Record<string, BiologyTerm> = Object.fromEntries(
  ALL_BIOLOGY_TERMS.map((term) => [term.id, term])
);

export const CATEGORY_META: Record<
  TermCategory,
  {
    label: string;
    shortLabel: string;
    stripBg: string;
    cardBg: string;
    borderColor: string;
    textColor: string;
    badgeBg: string;
  }
> = {
  cell_genetics: {
    label: 'Жасуша және генетика',
    shortLabel: 'Генетика',
    stripBg: 'bg-violet-600',
    cardBg: 'bg-violet-50',
    borderColor: 'border-violet-300',
    textColor: 'text-violet-900',
    badgeBg: 'bg-violet-100 text-violet-800',
  },
  human_biology: {
    label: 'Адам биологиясы',
    shortLabel: 'Адам',
    stripBg: 'bg-sky-600',
    cardBg: 'bg-sky-50',
    borderColor: 'border-sky-300',
    textColor: 'text-sky-900',
    badgeBg: 'bg-sky-100 text-sky-800',
  },
  plant_ecology: {
    label: 'Өсімдіктер мен экология',
    shortLabel: 'Табиғат',
    stripBg: 'bg-emerald-600',
    cardBg: 'bg-emerald-50',
    borderColor: 'border-emerald-300',
    textColor: 'text-emerald-900',
    badgeBg: 'bg-emerald-100 text-emerald-800',
  },
};

import {
  ActiveSessionState,
  LifetimeStats,
  SavedGameRecord,
  TermStatistic,
} from '../types/game';

const SESSION_KEY = 'biomonopoly_active_session_v1';
const STATS_KEY = 'biomonopoly_lifetime_stats_v1';

const DEFAULT_STATS: LifetimeStats = {
  totalGames: 0,
  totalQuestionsAnswered: 0,
  totalCorrect: 0,
  totalIncorrect: 0,
  totalBioCoinEarned: 0,
  termStats: {},
  recentGames: [],
};

export function loadActiveSession(): ActiveSessionState | null {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as ActiveSessionState;
    if (!parsed || !Array.isArray(parsed.players) || parsed.players.length < 2) {
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

export function saveActiveSession(session: ActiveSessionState): void {
  try {
    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  } catch {
    // ignore storage quota errors
  }
}

export function clearActiveSession(): void {
  try {
    localStorage.removeItem(SESSION_KEY);
  } catch {
    // ignore
  }
}

export function loadLifetimeStats(): LifetimeStats {
  try {
    const raw = localStorage.getItem(STATS_KEY);
    if (!raw) return { ...DEFAULT_STATS, termStats: {}, recentGames: [] };
    const parsed = JSON.parse(raw) as LifetimeStats;
    return {
      ...DEFAULT_STATS,
      ...parsed,
      termStats: parsed.termStats ?? {},
      recentGames: Array.isArray(parsed.recentGames) ? parsed.recentGames : [],
    };
  } catch {
    return { ...DEFAULT_STATS, termStats: {}, recentGames: [] };
  }
}

export function saveCompletedGameToStats(
  record: SavedGameRecord,
  sessionTermStats: Record<string, TermStatistic>,
  totalBioCoinEarnedInGame: number
): LifetimeStats {
  const prev = loadLifetimeStats();

  const mergedTermStats: Record<string, TermStatistic> = { ...prev.termStats };
  for (const [termId, stat] of Object.entries(sessionTermStats)) {
    const existing = mergedTermStats[termId] ?? {
      termId,
      visits: 0,
      attempts: 0,
      correct: 0,
      incorrect: 0,
    };
    mergedTermStats[termId] = {
      termId,
      visits: existing.visits + stat.visits,
      attempts: existing.attempts + stat.attempts,
      correct: existing.correct + stat.correct,
      incorrect: existing.incorrect + stat.incorrect,
    };
  }

  let gameCorrect = 0;
  let gameIncorrect = 0;
  for (const p of record.players) {
    gameCorrect += p.correctCount;
    gameIncorrect += p.incorrectCount;
  }

  const updated: LifetimeStats = {
    totalGames: prev.totalGames + 1,
    totalQuestionsAnswered: prev.totalQuestionsAnswered + gameCorrect + gameIncorrect,
    totalCorrect: prev.totalCorrect + gameCorrect,
    totalIncorrect: prev.totalIncorrect + gameIncorrect,
    totalBioCoinEarned: prev.totalBioCoinEarned + totalBioCoinEarnedInGame,
    termStats: mergedTermStats,
    recentGames: [record, ...prev.recentGames].slice(0, 12),
  };

  try {
    localStorage.setItem(STATS_KEY, JSON.stringify(updated));
  } catch {
    // ignore
  }
  return updated;
}

export function resetLifetimeStats(): LifetimeStats {
  const fresh: LifetimeStats = {
    totalGames: 0,
    totalQuestionsAnswered: 0,
    totalCorrect: 0,
    totalIncorrect: 0,
    totalBioCoinEarned: 0,
    termStats: {},
    recentGames: [],
  };
  try {
    localStorage.setItem(STATS_KEY, JSON.stringify(fresh));
  } catch {
    // ignore
  }
  return fresh;
}

import React, { useState } from 'react';
import { CheckCircle2, HelpCircle, Lightbulb, XCircle } from 'lucide-react';
import { CATEGORY_META } from '../data/biologyTerms';
import { BiologyQuestion, BiologyTerm, GameMode } from '../types/game';
import { BioCoinIcon } from './BioIcon';
import { TermIllustrationStage } from './TermIllustrationStage';

interface QuestionModalProps {
  term: BiologyTerm;
  question: BiologyQuestion;
  mode: GameMode;
  playerName: string;
  sourceLabel?: string;
  isRedZone?: boolean;
  rewardAmount?: number;
  penaltyAmount?: number;
  onComplete: (isCorrect: boolean) => void;
}

const OPTION_LETTERS = ['A', 'B', 'C', 'D'] as const;

export const QuestionModal: React.FC<QuestionModalProps> = ({
  term,
  question,
  mode,
  playerName,
  sourceLabel,
  isRedZone = false,
  rewardAmount = 100,
  penaltyAmount = 50,
  onComplete,
}) => {
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);
  const [showHint, setShowHint] = useState<boolean>(mode === 'learning');

  const isAnswered = selectedIdx !== null;
  const isCorrect = selectedIdx === question.correctIndex;
  const catMeta = CATEGORY_META[term.category];

  const handleSelect = (idx: number) => {
    if (isAnswered) return;
    setSelectedIdx(idx);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/65 p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="question-modal-title"
      data-testid="question-modal"
    >
      <div className="w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-pop-in my-auto">
        {/* Category / Red Zone Header */}
        <div className={`${isRedZone ? 'bg-rose-700' : catMeta.stripBg} px-6 py-4 text-white flex items-center justify-between gap-4`}>
          <div className="flex items-center gap-3.5 min-w-0">
            <TermIllustrationStage
              iconKey={isRedZone ? 'red_zone' : term.iconKey}
              category={isRedZone ? undefined : term.category}
              specialKind={isRedZone ? 'red_zone' : undefined}
              variant="headerBadge"
            />
            <div className="min-w-0">
              <div className="text-xs font-semibold text-white/85 truncate">
                {isRedZone
                  ? `Күрделі сұрақ · ${term.name} · ${playerName}`
                  : `${sourceLabel ?? catMeta.label} · ${playerName}`}
              </div>
              <h2 id="question-modal-title" className="font-display font-black text-xl sm:text-2xl truncate">
                {isRedZone ? 'Қызыл аймақ' : term.name}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-1.5 bg-black/20 px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap shrink-0">
            <BioCoinIcon className="w-4 h-4" />
            <span className="tabular-nums">+{rewardAmount}</span>
          </div>
        </div>

        <div className="p-6 space-y-5">
          {/* Learning Mode Assistant Hint (only in learning mode before answering) */}
          {mode === 'learning' && (
            <div className="rounded-xl bg-emerald-50 border border-emerald-200 p-3.5 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 text-xs font-bold text-emerald-900">
                  <Lightbulb className="w-4 h-4 text-emerald-700 shrink-0" />
                  <span>Үйрену режимі · Көмекші кеңес</span>
                </div>
                <button
                  type="button"
                  onClick={() => setShowHint((prev) => !prev)}
                  className="text-xs font-bold text-emerald-700 hover:underline cursor-pointer whitespace-nowrap"
                >
                  {showHint ? 'Жасыру' : 'Кеңесті ашу'}
                </button>
              </div>
              {showHint && (
                <div className="text-sm text-emerald-950 space-y-1">
                  <p>{term.hint}</p>
                  <p className="text-xs text-emerald-800">
                    <strong>Мысал:</strong> {term.example}
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Question Text */}
          <div>
            <p className="font-display font-bold text-lg text-slate-900 leading-snug">
              {question.question}
            </p>
          </div>

          {/* 4 Answer Options */}
          <div className="space-y-2.5">
            {question.options.map((option, idx) => {
              const isSelected = selectedIdx === idx;
              const isRightOption = idx === question.correctIndex;

              let styleClass =
                'bg-slate-50 border-slate-200 text-slate-800 hover:bg-emerald-50 hover:border-emerald-300';
              if (isAnswered) {
                if (isRightOption) {
                  styleClass = 'bg-emerald-50 border-emerald-500 text-emerald-950 ring-2 ring-emerald-500/30';
                } else if (isSelected && !isRightOption) {
                  styleClass = 'bg-rose-50 border-rose-500 text-rose-950 ring-2 ring-rose-500/20';
                } else {
                  styleClass = 'bg-slate-50 border-slate-200 text-slate-400 opacity-75';
                }
              }

              return (
                <button
                  key={idx}
                  type="button"
                  disabled={isAnswered}
                  onClick={() => handleSelect(idx)}
                  data-testid={`answer-option-${idx}`}
                  className={`w-full flex items-center gap-3 p-3.5 rounded-xl border text-left transition-all cursor-pointer disabled:cursor-default focus-visible:outline-2 focus-visible:outline-emerald-600 ${styleClass}`}
                >
                  <span
                    className={`w-8 h-8 rounded-lg flex items-center justify-center font-mono font-bold text-sm shrink-0 ${
                      isAnswered && isRightOption
                        ? 'bg-emerald-600 text-white'
                        : isAnswered && isSelected && !isRightOption
                          ? 'bg-rose-600 text-white'
                          : 'bg-white border border-slate-300 text-slate-700'
                    }`}
                  >
                    {OPTION_LETTERS[idx]}
                  </span>
                  <span className="text-sm sm:text-base font-medium leading-snug flex-1">
                    {option}
                  </span>
                  {isAnswered && isRightOption && (
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  )}
                  {isAnswered && isSelected && !isRightOption && (
                    <XCircle className="w-5 h-5 text-rose-600 shrink-0" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Feedback & Explanation */}
          {isAnswered && (
            <div
              data-testid="question-feedback"
              className={`rounded-xl p-4 border space-y-2 animate-pop-in ${
                isCorrect
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                  : 'bg-rose-50 border-rose-300 text-rose-950'
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 font-display font-black text-base">
                  {isCorrect ? (
                    <>
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                      <span>Дұрыс жауап!</span>
                    </>
                  ) : (
                    <>
                      <XCircle className="w-5 h-5 text-rose-600 shrink-0" />
                      <span>Қате жауап!</span>
                    </>
                  )}
                </div>
                <span className="font-mono font-bold text-sm tabular-nums">
                  {isCorrect ? `+${rewardAmount} BioCoin` : penaltyAmount > 0 ? `-${penaltyAmount} BioCoin` : '0 BioCoin'}
                </span>
              </div>

              {!isCorrect && (
                <p className="text-xs sm:text-sm font-semibold text-rose-900">
                  Дұрыс жауап: {OPTION_LETTERS[question.correctIndex]}. {question.options[question.correctIndex]}
                </p>
              )}

              <p className="text-sm leading-relaxed">{question.explanation}</p>

              {(mode === 'learning' || !isCorrect) && (
                <p className="text-xs font-semibold text-slate-700 pt-1 border-t border-black/10">
                  Есте сақтау: {term.memoryTip}
                </p>
              )}
            </div>
          )}

          {/* Action Footer */}
          {isAnswered ? (
            <button
              type="button"
              onClick={() => onComplete(isCorrect)}
              data-testid="question-continue-btn"
              className="w-full py-3 px-5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-display font-bold text-base transition-colors cursor-pointer whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-emerald-600"
            >
              Түсіндім · Жалғастыру
            </button>
          ) : (
            <div className="flex items-center justify-center gap-1.5 text-xs text-slate-500">
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Жауап нұсқаларының бірін таңдаңыз</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { SpecialCellType, TermCategory } from '../types/game';
import { BioIcon } from './BioIcon';

interface TermIllustrationStageProps {
  iconKey: string;
  category?: TermCategory;
  specialKind?: SpecialCellType;
  variant: 'board' | 'card' | 'modal' | 'headerBadge';
  isCorner?: boolean;
}

function getThemeStyles(category?: TermCategory, specialKind?: SpecialCellType) {
  if (category === 'cell_genetics') {
    return {
      bg: 'bg-gradient-to-br from-violet-200/90 via-purple-50 to-indigo-100/90',
      ring: 'border-violet-300/80',
      patternStroke: '#7C3AED',
      orbColor: 'bg-violet-300/35',
    };
  }
  if (category === 'human_biology') {
    return {
      bg: 'bg-gradient-to-br from-sky-200/90 via-cyan-50 to-blue-100/90',
      ring: 'border-sky-300/80',
      patternStroke: '#0284C7',
      orbColor: 'bg-sky-300/35',
    };
  }
  if (category === 'plant_ecology') {
    return {
      bg: 'bg-gradient-to-br from-emerald-200/90 via-lime-50 to-teal-100/90',
      ring: 'border-emerald-300/80',
      patternStroke: '#15803D',
      orbColor: 'bg-emerald-300/35',
    };
  }
  if (specialKind === 'chance' || specialKind === 'jail') {
    return {
      bg: 'bg-gradient-to-br from-orange-200/85 via-amber-50 to-orange-100/90',
      ring: 'border-orange-300/80',
      patternStroke: '#EA580C',
      orbColor: 'bg-orange-300/35',
    };
  }
  if (specialKind === 'red_zone') {
    return {
      bg: 'bg-gradient-to-br from-rose-200/90 via-red-50 to-rose-100/90',
      ring: 'border-rose-400/80',
      patternStroke: '#E11D48',
      orbColor: 'bg-rose-300/40',
    };
  }
  if (specialKind === 'start') {
    return {
      bg: 'bg-gradient-to-br from-amber-200/90 via-yellow-50 to-amber-100/90',
      ring: 'border-amber-300/80',
      patternStroke: '#D97706',
      orbColor: 'bg-amber-300/40',
    };
  }
  return {
    bg: 'bg-gradient-to-br from-emerald-200/85 via-emerald-50 to-teal-100/90',
    ring: 'border-emerald-300/80',
    patternStroke: '#15803D',
    orbColor: 'bg-emerald-300/35',
  };
}

const BackdropPattern: React.FC<{ stroke: string }> = ({ stroke }) => (
  <svg
    viewBox="0 0 240 140"
    className="absolute inset-0 w-full h-full opacity-20 pointer-events-none"
    preserveAspectRatio="xMidYMid slice"
    aria-hidden="true"
  >
    <circle cx="42" cy="36" r="28" fill="none" stroke={stroke} strokeWidth="1.4" strokeDasharray="4 4" />
    <circle cx="198" cy="104" r="36" fill="none" stroke={stroke} strokeWidth="1.4" />
    <circle cx="198" cy="104" r="18" fill="none" stroke={stroke} strokeWidth="1.1" strokeDasharray="3 3" />
    <circle cx="120" cy="70" r="52" fill="none" stroke={stroke} strokeWidth="1.2" />
    <path d="M18 112c24-18 42-14 64 2M156 26c22 14 40 12 62-6" fill="none" stroke={stroke} strokeWidth="1.3" strokeLinecap="round" />
    <circle cx="76" cy="24" r="3" fill={stroke} />
    <circle cx="164" cy="116" r="3.5" fill={stroke} />
    <circle cx="28" cy="86" r="2.5" fill={stroke} />
  </svg>
);

export const TermIllustrationStage: React.FC<TermIllustrationStageProps> = ({
  iconKey,
  category,
  specialKind,
  variant,
  isCorner = false,
}) => {
  const theme = getThemeStyles(category, specialKind);

  if (variant === 'board') {
    return (
      <div
        className={`relative flex items-center justify-center rounded-xl border ${theme.bg} ${theme.ring} shadow-inner ${
          isCorner ? 'w-10 h-10 sm:w-12 sm:h-12' : 'w-7 h-7 sm:w-9 sm:h-9'
        }`}
      >
        <span
          className={`absolute inset-1 rounded-lg bg-white/65 pointer-events-none`}
          aria-hidden="true"
        />
        <BioIcon
          iconKey={iconKey}
          className={`relative z-10 ${isCorner ? 'w-7 h-7 sm:w-9 sm:h-9' : 'w-5 h-5 sm:w-7 sm:h-7'}`}
        />
      </div>
    );
  }

  if (variant === 'headerBadge') {
    return (
      <div className={`relative w-16 h-16 rounded-2xl border-2 border-white/80 ${theme.bg} flex items-center justify-center shrink-0 shadow-md overflow-hidden`}>
        <BackdropPattern stroke={theme.patternStroke} />
        <div className="relative z-10 w-12 h-12 rounded-xl bg-white/85 shadow-sm flex items-center justify-center">
          <BioIcon iconKey={iconKey} className="w-10 h-10" />
        </div>
      </div>
    );
  }

  if (variant === 'modal') {
    return (
      <div className={`relative w-full h-40 rounded-2xl border ${theme.ring} ${theme.bg} flex items-center justify-center overflow-hidden shadow-inner`}>
        <BackdropPattern stroke={theme.patternStroke} />
        <div className={`absolute w-32 h-32 rounded-full ${theme.orbColor} blur-xl pointer-events-none`} aria-hidden="true" />
        <div className="relative z-10 w-28 h-28 rounded-3xl bg-white/90 border border-white shadow-lg flex items-center justify-center">
          <BioIcon iconKey={iconKey} className="w-22 h-22" />
        </div>
      </div>
    );
  }

  // 'card' variant for TermsLibrary grid
  return (
    <div className={`relative w-full h-32 rounded-xl border ${theme.ring} ${theme.bg} flex items-center justify-center overflow-hidden`}>
      <BackdropPattern stroke={theme.patternStroke} />
      <div className={`absolute w-24 h-24 rounded-full ${theme.orbColor} blur-lg pointer-events-none`} aria-hidden="true" />
      <div className="relative z-10 w-22 h-22 rounded-2xl bg-white/90 border border-white shadow-md flex items-center justify-center transition-transform duration-200 group-hover:scale-105">
        <BioIcon iconKey={iconKey} className="w-16 h-16" />
      </div>
    </div>
  );
};

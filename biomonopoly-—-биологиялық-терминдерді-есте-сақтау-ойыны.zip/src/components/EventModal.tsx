import React from 'react';
import { JAIL_BAIL_COST } from '../game/rules';
import { ChanceCard, SpecialCellType } from '../types/game';
import { BioCoinIcon, BioIcon } from './BioIcon';

interface EventModalProps {
  eventType: SpecialCellType;
  playerName: string;
  playerBalance: number;
  chanceCard?: ChanceCard | null;
  passedStartBonus?: number;
  onAcknowledgeStartOrRest: () => void;
  onResolveChance: (card: ChanceCard) => void;
  onJailAnswerQuestion: () => void;
  onJailPayBail: () => void;
  onJailSkipTurn: () => void;
}

export const EventModal: React.FC<EventModalProps> = ({
  eventType,
  playerName,
  playerBalance,
  chanceCard,
  passedStartBonus = 0,
  onAcknowledgeStartOrRest,
  onResolveChance,
  onJailAnswerQuestion,
  onJailPayBail,
  onJailSkipTurn,
}) => {
  const canPay = playerBalance >= JAIL_BAIL_COST;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/65 p-4"
      role="dialog"
      aria-modal="true"
      data-testid="event-modal"
    >
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-pop-in">
        {eventType === 'chance' && chanceCard && (
          <>
            <div className="bg-orange-600 px-6 py-4 text-white flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-white flex items-center justify-center shrink-0">
                <BioIcon iconKey="chance" className="w-7 h-7" />
              </div>
              <div>
                <div className="text-xs font-semibold text-orange-100">Шанс оқиғасы · {playerName}</div>
                <h2 className="font-display font-black text-xl">{chanceCard.title}</h2>
              </div>
            </div>

            <div className="p-6 space-y-4">
              <div className="rounded-xl overflow-hidden border border-orange-200 h-36 bg-orange-50">
                <img
                  src="/src/assets/images/card_chance_cover_1794893184369.jpg"
                  alt="Шанс картасы"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>

              <p className="text-slate-700 text-sm sm:text-base leading-relaxed">
                {chanceCard.description}
              </p>

              {chanceCard.effectType !== 'bonus_question' && chanceCard.amount && (
                <div
                  className={`flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl font-display font-black text-lg tabular-nums ${
                    chanceCard.effectType === 'add_coins'
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      : 'bg-rose-50 text-rose-800 border border-rose-200'
                  }`}
                >
                  <BioCoinIcon className="w-5 h-5" />
                  <span>
                    {chanceCard.effectType === 'add_coins' ? `+${chanceCard.amount}` : `-${chanceCard.amount}`} BioCoin
                  </span>
                </div>
              )}

              <button
                type="button"
                onClick={() => onResolveChance(chanceCard)}
                data-testid="event-confirm-btn"
                className="w-full py-3 px-5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-display font-bold text-base transition-colors cursor-pointer whitespace-nowrap"
              >
                {chanceCard.effectType === 'bonus_question' ? 'Бонустық сұраққа өту' : 'Қабылдау · Жалғастыру'}
              </button>
            </div>
          </>
        )}

        {eventType === 'jail' && (
          <>
            <div className="bg-orange-700 px-6 py-4 text-white flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-white flex items-center justify-center shrink-0">
                <BioIcon iconKey="jail" className="w-7 h-7" />
              </div>
              <div>
                <div className="text-xs font-semibold text-orange-100">Түрме · {playerName}</div>
                <h2 className="font-display font-black text-xl">Зертхана карантині</h2>
              </div>
            </div>

            <div className="p-6 space-y-4">
              <p className="text-slate-700 text-sm sm:text-base leading-relaxed">
                Сен «Түрме» ұяшығына түстің! Босап шығу үшін арнайы биологиялық сұраққа дұрыс жауап бер немесе {JAIL_BAIL_COST} BioCoin төле.
              </p>

              <div className="space-y-2.5">
                <button
                  type="button"
                  onClick={onJailAnswerQuestion}
                  data-testid="jail-question-btn"
                  className="w-full py-3 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-display font-bold text-sm sm:text-base transition-colors cursor-pointer"
                >
                  Арнайы биология сұрағына жауап беру
                </button>

                <button
                  type="button"
                  disabled={!canPay}
                  onClick={onJailPayBail}
                  data-testid="jail-pay-btn"
                  className="w-full py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-600 disabled:bg-slate-200 disabled:text-slate-400 text-slate-950 font-display font-bold text-sm sm:text-base transition-colors cursor-pointer disabled:cursor-not-allowed"
                >
                  {JAIL_BAIL_COST} BioCoin төлеп шығу (Баланс: {playerBalance})
                </button>

                <button
                  type="button"
                  onClick={onJailSkipTurn}
                  data-testid="jail-skip-btn"
                  className="w-full py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-sm transition-colors cursor-pointer"
                >
                  Осы кезекті өткізіп жіберу
                </button>
              </div>
            </div>
          </>
        )}

        {eventType === 'rest' && (
          <>
            <div className="bg-emerald-700 px-6 py-4 text-white flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-white flex items-center justify-center shrink-0">
                <BioIcon iconKey="rest" className="w-7 h-7" />
              </div>
              <div>
                <div className="text-xs font-semibold text-emerald-100">Демалыс · {playerName}</div>
                <h2 className="font-display font-black text-xl">Ботаника бағында демалыс</h2>
              </div>
            </div>

            <div className="p-6 space-y-4">
              <p className="text-slate-700 text-sm sm:text-base leading-relaxed">
                Құттықтаймыз! Сен BioCoin жоғалтпай тынығып, келесі айналымға күш жинайсың.
              </p>
              <button
                type="button"
                onClick={onAcknowledgeStartOrRest}
                data-testid="event-confirm-btn"
                className="w-full py-3 px-5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-display font-bold text-base transition-colors cursor-pointer"
              >
                Келесі кезекке өту
              </button>
            </div>
          </>
        )}

        {eventType === 'start' && (
          <>
            <div className="bg-amber-500 px-6 py-4 text-slate-950 flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-white flex items-center justify-center shrink-0">
                <BioIcon iconKey="start" className="w-7 h-7" />
              </div>
              <div>
                <div className="text-xs font-bold text-amber-950/80">Бастау · {playerName}</div>
                <h2 className="font-display font-black text-xl">Айналым аяқталды!</h2>
              </div>
            </div>

            <div className="p-6 space-y-4">
              <p className="text-slate-700 text-sm sm:text-base leading-relaxed">
                Сен «Бастау» ұяшығына жеттің! Ағзалар әлемін зерттегенің үшін сыйақы алдың.
              </p>
              <div className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-amber-50 border border-amber-300 text-amber-900 font-display font-black text-lg tabular-nums">
                <BioCoinIcon className="w-5 h-5" />
                <span>+{passedStartBonus || 100} BioCoin</span>
              </div>
              <button
                type="button"
                onClick={onAcknowledgeStartOrRest}
                data-testid="event-confirm-btn"
                className="w-full py-3 px-5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-display font-bold text-base transition-colors cursor-pointer"
              >
                Жалғастыру
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

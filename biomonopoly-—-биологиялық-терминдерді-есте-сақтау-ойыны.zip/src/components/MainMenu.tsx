import React from 'react';
import { BarChart3, BookOpen, Compass, HelpCircle, Play, RotateCw } from 'lucide-react';
import { BioCoinIcon } from './BioIcon';

interface MainMenuProps {
  hasSavedSession: boolean;
  onStartGame: () => void;
  onStartLearningMode: () => void;
  onResumeSaved: () => void;
  onOpenRules: () => void;
  onOpenTerms: () => void;
  onOpenResults: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  hasSavedSession,
  onStartGame,
  onStartLearningMode,
  onResumeSaved,
  onOpenRules,
  onOpenTerms,
  onOpenResults,
}) => {
  return (
    <main className="min-h-screen flex items-center justify-center p-4 sm:p-8">
      <div className="w-full max-w-6xl bg-[#f7f5ee] rounded-3xl shadow-2xl border-4 border-emerald-950/25 overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch">
          {/* Left Column: Title, Intro, and Menu Actions */}
          <div className="lg:col-span-6 p-6 sm:p-10 flex flex-col justify-between gap-6">
            <div className="space-y-4">
              {/* Brand Emblem */}
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-emerald-700 text-white flex items-center justify-center shadow-md shrink-0">
                  <BioCoinIcon className="w-8 h-8" />
                </div>
                <div>
                  <h1 className="font-display font-black text-3xl sm:text-5xl tracking-tight text-emerald-950 leading-none">
                    BioMonopoly
                  </h1>
                  <p className="text-sm sm:text-base font-bold text-emerald-700 mt-1">
                    Биологиялық терминдерді есте сақтау ойыны
                  </p>
                </div>
              </div>

              {/* Exact Requested Kazakh Introduction */}
              <p className="text-slate-700 text-base sm:text-lg leading-relaxed max-w-xl pt-2">
                Биология әлеміне саяхат жаса! Кубикті лақтыр, терминдерге тап бол, сұрақтарға жауап бер және BioCoin жина! Кім биологияны жақсы меңгеріп, ең көп BioCoin жинайды?
              </p>
            </div>

            {/* Menu Actions */}
            <div className="space-y-3">
              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  type="button"
                  onClick={onStartGame}
                  data-start="true"
                  data-testid="menu-start-btn"
                  className="flex-1 inline-flex items-center justify-center gap-2.5 px-6 py-4 rounded-2xl bg-emerald-700 hover:bg-emerald-800 text-white font-display font-black text-lg shadow-[0_4px_0_#064e3b] active:translate-y-0.5 active:shadow-[0_2px_0_#064e3b] transition-all cursor-pointer whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-emerald-700"
                >
                  <Play className="w-5 h-5 fill-current" />
                  <span>Ойынды бастау</span>
                </button>

                <button
                  type="button"
                  onClick={onStartLearningMode}
                  data-testid="menu-learning-btn"
                  className="inline-flex items-center justify-center gap-2 px-5 py-4 rounded-2xl bg-violet-700 hover:bg-violet-800 text-white font-display font-bold text-base shadow-[0_4px_0_#4c1d95] active:translate-y-0.5 transition-all cursor-pointer whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-700"
                >
                  <Compass className="w-5 h-5" />
                  <span>Оқу режимі</span>
                </button>
              </div>

              {hasSavedSession && (
                <button
                  type="button"
                  onClick={onResumeSaved}
                  data-testid="menu-resume-btn"
                  className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-amber-100 hover:bg-amber-200 border border-amber-300 text-amber-950 font-display font-bold text-sm transition-colors cursor-pointer whitespace-nowrap"
                >
                  <RotateCw className="w-4 h-4" />
                  <span>Сақталған ойынды жалғастыру</span>
                </button>
              )}

              <div className="flex flex-wrap gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={onOpenTerms}
                  data-testid="menu-terms-btn"
                  className="flex-auto inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-white hover:bg-emerald-50 border border-emerald-900/15 text-emerald-950 font-display font-bold text-sm transition-colors cursor-pointer whitespace-nowrap"
                >
                  <BookOpen className="w-4 h-4 text-emerald-700 shrink-0" />
                  <span>Биологиялық терминдер</span>
                </button>

                <button
                  type="button"
                  onClick={onOpenRules}
                  data-testid="menu-rules-btn"
                  className="flex-auto inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-white hover:bg-emerald-50 border border-emerald-900/15 text-emerald-950 font-display font-bold text-sm transition-colors cursor-pointer whitespace-nowrap"
                >
                  <HelpCircle className="w-4 h-4 text-sky-700 shrink-0" />
                  <span>Ойын ережелері</span>
                </button>

                <button
                  type="button"
                  onClick={onOpenResults}
                  data-testid="menu-results-btn"
                  className="flex-auto inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-white hover:bg-emerald-50 border border-emerald-900/15 text-emerald-950 font-display font-bold text-sm transition-colors cursor-pointer whitespace-nowrap"
                >
                  <BarChart3 className="w-4 h-4 text-orange-600 shrink-0" />
                  <span>Нәтижелер</span>
                </button>
              </div>
            </div>

            <div className="pt-2 border-t border-emerald-950/10 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs font-medium text-slate-600">
              <span>2–4 ойыншы</span>
              <span aria-hidden="true">·</span>
              <span>36 ойын ұяшығы</span>
              <span aria-hidden="true">·</span>
              <span>29 биологиялық термин</span>
              <span aria-hidden="true">·</span>
              <span>7-сынып бағдарламасы</span>
            </div>
          </div>

          {/* Right Column: Large Illustrated Biological Board */}
          <div className="lg:col-span-6 bg-emerald-900 relative min-h-[300px] sm:min-h-[420px] flex items-center justify-center overflow-hidden">
            <img
              src="/src/assets/images/biomonopoly_hero_art_1794893183160.jpg"
              alt="BioMonopoly биологиялық үстел ойынының иллюстрациясы"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-emerald-950/80 via-emerald-950/15 to-transparent pointer-events-none" />
            <div className="absolute bottom-5 left-5 right-5 text-white flex items-end justify-between gap-4">
              <div>
                <div className="text-xs font-semibold text-emerald-200">
                  Интерактивті үстел ойыны
                </div>
                <div className="font-display font-black text-lg sm:text-xl leading-snug">
                  Жасуша, генетика, адам ағзасы және экожүйе
                </div>
              </div>
              <div className="bg-amber-400 text-emerald-950 px-3 py-1.5 rounded-xl font-mono font-bold text-xs whitespace-nowrap shrink-0 shadow">
                500 BioCoin
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
};

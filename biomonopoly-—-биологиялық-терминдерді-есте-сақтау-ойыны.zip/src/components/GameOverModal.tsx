import React from 'react';
import { Award, Home, RotateCcw, Trophy } from 'lucide-react';
import { calculateAccuracy, rankPlayers } from '../game/rules';
import { TERMS_BY_ID } from '../data/biologyTerms';
import { Player, TermStatistic } from '../types/game';
import { BioCoinIcon } from './BioIcon';
import { PlayerAvatar } from './PlayerAvatar';

interface GameOverModalProps {
  players: Player[];
  roundsPlayed: number;
  termStats: Record<string, TermStatistic>;
  onPlayAgain: () => void;
  onReturnToMenu: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  players,
  roundsPlayed,
  termStats,
  onPlayAgain,
  onReturnToMenu,
}) => {
  const ranked = rankPlayers(players);
  const winner = ranked[0];
  const winnerAccuracy = calculateAccuracy(winner.correctCount, winner.incorrectCount);

  const statList = Object.values(termStats);
  const mostVisited = [...statList].sort((a, b) => b.visits - a.visits).slice(0, 3);
  const hardestTerms = [...statList]
    .filter((s) => s.incorrect > 0)
    .sort((a, b) => b.incorrect - a.incorrect)
    .slice(0, 3);

  return (
    <div
      className="min-h-screen flex items-center justify-center p-4 sm:p-6"
      data-testid="gameover-screen"
    >
      <div className="w-full max-w-3xl bg-white rounded-3xl shadow-2xl border border-emerald-900/15 overflow-hidden animate-pop-in">
        {/* Winner Hero Banner */}
        <div className="bg-emerald-800 px-6 py-8 text-white text-center relative overflow-hidden">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-amber-400 text-emerald-950 shadow-lg mb-3">
            <Trophy className="w-9 h-9" />
          </div>
          <h1 className="font-display font-black text-2xl sm:text-4xl tracking-tight">
            BIO MONOPOLY ЖЕҢІМПАЗЫ!
          </h1>
          <p className="text-emerald-100 text-sm mt-1">
            {roundsPlayed} айналым қорытындысы бойынша үздік биолог анықталды
          </p>

          {/* Winner Spotlight */}
          <div className="mt-6 inline-flex flex-col sm:flex-row items-center gap-4 bg-white/10 border border-white/20 rounded-2xl px-6 py-4">
            <PlayerAvatar avatarId={winner.avatarId} color={winner.color} size="lg" />
            <div className="text-center sm:text-left">
              <div className="text-xs font-semibold text-amber-300">1-орын · Жеңімпаз</div>
              <div className="font-display font-black text-2xl">{winner.name}</div>
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 mt-1 text-sm text-emerald-100 tabular-nums">
                <span className="inline-flex items-center gap-1 font-bold text-amber-300">
                  <BioCoinIcon className="w-4 h-4" />
                  {winner.balance} BioCoin
                </span>
                <span>·</span>
                <span>Дұрыс: {winner.correctCount}</span>
                <span>·</span>
                <span>Дәлдік: {winnerAccuracy}%</span>
              </div>
            </div>
          </div>
        </div>

        <div className="p-6 sm:p-8 space-y-6">
          {/* Full Ranking Table */}
          <div>
            <h2 className="font-display font-extrabold text-lg text-slate-900 mb-3 flex items-center gap-2">
              <Award className="w-5 h-5 text-emerald-700" />
              <span>Ойыншылар рейтингі</span>
            </h2>
            <div className="overflow-x-auto border border-slate-200 rounded-xl">
              <table className="w-full text-left text-sm">
                <thead className="bg-slate-50 text-slate-600 text-xs font-bold border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4">Орын</th>
                    <th className="py-3 px-4">Ойыншы</th>
                    <th className="py-3 px-4">BioCoin</th>
                    <th className="py-3 px-4">Дұрыс / Қате</th>
                    <th className="py-3 px-4">Терминдер</th>
                    <th className="py-3 px-4">Дәлдік</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 tabular-nums">
                  {ranked.map((player, idx) => {
                    const acc = calculateAccuracy(player.correctCount, player.incorrectCount);
                    return (
                      <tr key={player.id} className={idx === 0 ? 'bg-amber-50/60 font-semibold' : ''}>
                        <td className="py-3 px-4 font-mono font-bold text-slate-700">#{idx + 1}</td>
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2.5">
                            <PlayerAvatar avatarId={player.avatarId} color={player.color} size="sm" />
                            <span className="text-slate-900 font-bold">{player.name}</span>
                          </div>
                        </td>
                        <td className="py-3 px-4 font-mono font-bold text-amber-700">
                          {player.balance}
                        </td>
                        <td className="py-3 px-4">
                          <span className="text-emerald-700 font-bold">{player.correctCount}</span>
                          {' / '}
                          <span className="text-rose-600 font-bold">{player.incorrectCount}</span>
                        </td>
                        <td className="py-3 px-4 text-slate-700">
                          {player.visitedTermIds.length}
                        </td>
                        <td className="py-3 px-4 font-mono font-bold text-slate-800">{acc}%</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Learning Summary */}
          {statList.length > 0 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="rounded-xl bg-emerald-50 border border-emerald-200 p-4">
                <h3 className="font-display font-bold text-sm text-emerald-950 mb-2">
                  Жиі кездескен терминдер
                </h3>
                {mostVisited.length === 0 ? (
                  <p className="text-xs text-emerald-800">Деректер жоқ</p>
                ) : (
                  <ul className="space-y-1.5 text-sm">
                    {mostVisited.map((s) => (
                      <li key={s.termId} className="flex items-center justify-between text-emerald-900">
                        <span className="font-semibold">{TERMS_BY_ID[s.termId]?.name ?? s.termId}</span>
                        <span className="font-mono text-xs tabular-nums">{s.visits} рет</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              <div className="rounded-xl bg-orange-50 border border-orange-200 p-4">
                <h3 className="font-display font-bold text-sm text-orange-950 mb-2">
                  Қайталауды қажет ететін терминдер
                </h3>
                {hardestTerms.length === 0 ? (
                  <p className="text-xs text-orange-900">Қате жауаптар тіркелген жоқ — тамаша нәтиже!</p>
                ) : (
                  <ul className="space-y-1.5 text-sm">
                    {hardestTerms.map((s) => (
                      <li key={s.termId} className="flex items-center justify-between text-orange-950">
                        <span className="font-semibold">{TERMS_BY_ID[s.termId]?.name ?? s.termId}</span>
                        <span className="font-mono text-xs tabular-nums">{s.incorrect} қате</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <button
              type="button"
              onClick={onPlayAgain}
              data-start="true"
              data-testid="play-again-btn"
              className="flex-1 inline-flex items-center justify-center gap-2 py-3 px-5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-display font-bold text-base transition-colors cursor-pointer whitespace-nowrap"
            >
              <RotateCcw className="w-5 h-5" />
              <span>Қайта ойнау</span>
            </button>
            <button
              type="button"
              onClick={onReturnToMenu}
              data-testid="return-menu-btn"
              className="flex-1 inline-flex items-center justify-center gap-2 py-3 px-5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-display font-bold text-base transition-colors cursor-pointer whitespace-nowrap"
            >
              <Home className="w-5 h-5" />
              <span>Басты мәзірге оралу</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

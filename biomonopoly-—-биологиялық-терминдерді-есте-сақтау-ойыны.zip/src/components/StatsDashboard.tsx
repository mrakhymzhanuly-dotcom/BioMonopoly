import React from 'react';
import { ArrowLeft, BarChart3, CheckCircle2, Trash2, TrendingUp } from 'lucide-react';
import { calculateAccuracy } from '../game/rules';
import { TERMS_BY_ID } from '../data/biologyTerms';
import { LifetimeStats } from '../types/game';
import { BioCoinIcon } from './BioIcon';

interface StatsDashboardProps {
  stats: LifetimeStats;
  onBack: () => void;
  onResetStats: () => void;
}

export const StatsDashboard: React.FC<StatsDashboardProps> = ({
  stats,
  onBack,
  onResetStats,
}) => {
  const overallAccuracy = calculateAccuracy(stats.totalCorrect, stats.totalIncorrect);
  const termList = Object.values(stats.termStats);
  const mostVisited = [...termList].sort((a, b) => b.visits - a.visits).slice(0, 5);
  const hardestTerms = [...termList]
    .filter((s) => s.incorrect > 0)
    .sort((a, b) => b.incorrect - a.incorrect)
    .slice(0, 5);

  return (
    <main className="min-h-screen p-4 sm:p-8 flex justify-center" data-testid="results-screen">
      <div className="w-full max-w-5xl bg-[#f7f5ee] rounded-3xl shadow-2xl border-4 border-emerald-950/20 overflow-hidden">
        <div className="bg-emerald-800 px-6 py-5 text-white flex flex-wrap items-center justify-between gap-4">
          <button
            type="button"
            onClick={onBack}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/15 hover:bg-white/25 text-sm font-bold transition-colors cursor-pointer whitespace-nowrap"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Басты мәзір</span>
          </button>

          <h1 className="font-display font-black text-xl sm:text-2xl">
            Нәтижелер мен оқу статистикасы
          </h1>

          {stats.totalGames > 0 ? (
            <button
              type="button"
              onClick={onResetStats}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/15 hover:bg-rose-600 text-xs font-bold transition-colors cursor-pointer whitespace-nowrap"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Тазалау</span>
            </button>
          ) : (
            <div className="w-20 hidden sm:block" />
          )}
        </div>

        <div className="p-6 sm:p-8 space-y-6">
          {/* Summary KPI Row */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 tabular-nums">
            <div className="bg-white rounded-2xl p-4 border border-slate-200">
              <div className="text-xs font-bold text-slate-500">Жауап берілген сұрақтар</div>
              <div className="font-display font-black text-2xl sm:text-3xl text-slate-900 mt-1">
                {stats.totalQuestionsAnswered}
              </div>
              <div className="text-xs text-slate-500 mt-1">Аяқталған ойындар: {stats.totalGames}</div>
            </div>

            <div className="bg-white rounded-2xl p-4 border border-slate-200">
              <div className="text-xs font-bold text-slate-500">Дұрыс / Қате жауаптар</div>
              <div className="font-display font-black text-2xl sm:text-3xl mt-1">
                <span className="text-emerald-700">{stats.totalCorrect}</span>
                <span className="text-slate-300 mx-1.5">/</span>
                <span className="text-rose-600">{stats.totalIncorrect}</span>
              </div>
              <div className="text-xs text-slate-500 mt-1">Жалпы дәлдік көрсеткіші</div>
            </div>

            <div className="bg-white rounded-2xl p-4 border border-slate-200">
              <div className="text-xs font-bold text-slate-500">Орташа дәлдік</div>
              <div className="font-display font-black text-2xl sm:text-3xl text-emerald-700 mt-1 flex items-center gap-2">
                <span>{overallAccuracy}%</span>
                <CheckCircle2 className="w-6 h-6 text-emerald-600" />
              </div>
              <div className="text-xs text-slate-500 mt-1">Білім меңгеру деңгейі</div>
            </div>

            <div className="bg-white rounded-2xl p-4 border border-slate-200">
              <div className="text-xs font-bold text-slate-500">Жиналған BioCoin</div>
              <div className="font-display font-black text-2xl sm:text-3xl text-amber-600 mt-1 flex items-center gap-2">
                <BioCoinIcon className="w-6 h-6" />
                <span>{stats.totalBioCoinEarned}</span>
              </div>
              <div className="text-xs text-slate-500 mt-1">Барлық ойындар бойынша</div>
            </div>
          </div>

          {stats.totalGames === 0 && stats.totalQuestionsAnswered === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-10 text-center space-y-2">
              <BarChart3 className="w-10 h-10 text-emerald-700 mx-auto opacity-75" />
              <h2 className="font-display font-bold text-lg text-slate-900">
                Әзірге сақталған ойын нәтижелері жоқ
              </h2>
              <p className="text-sm text-slate-600 max-w-md mx-auto">
                Ойын ойнап, сұрақтарға жауап бергеннен кейін мұнда толық оқу есебі, қиын терминдер және ойыншылар дәлдігі көрсетіледі.
              </p>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-white rounded-2xl p-5 border border-slate-200 space-y-3">
                  <div className="flex items-center gap-2 font-display font-bold text-base text-slate-900">
                    <TrendingUp className="w-5 h-5 text-emerald-700" />
                    <h2>Ең жиі кездескен терминдер</h2>
                  </div>
                  {mostVisited.length === 0 ? (
                    <p className="text-sm text-slate-500">Мәлімет жоқ</p>
                  ) : (
                    <div className="space-y-2">
                      {mostVisited.map((s) => (
                        <div
                          key={s.termId}
                          className="flex items-center justify-between text-sm py-1.5 border-b border-slate-100 last:border-0"
                        >
                          <span className="font-bold text-slate-800">
                            {TERMS_BY_ID[s.termId]?.name ?? s.termId}
                          </span>
                          <span className="text-xs font-mono text-slate-600 tabular-nums">
                            {s.visits} рет · {calculateAccuracy(s.correct, s.incorrect)}% дәлдік
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="bg-white rounded-2xl p-5 border border-slate-200 space-y-3">
                  <h2 className="font-display font-bold text-base text-slate-900">
                    Ең қиын терминдер (қайталау ұсынылады)
                  </h2>
                  {hardestTerms.length === 0 ? (
                    <p className="text-sm text-emerald-700 font-medium">
                      Әзірге қиындық тудырған терминдер тіркелмеді!
                    </p>
                  ) : (
                    <div className="space-y-2">
                      {hardestTerms.map((s) => (
                        <div
                          key={s.termId}
                          className="flex items-center justify-between text-sm py-1.5 border-b border-slate-100 last:border-0"
                        >
                          <span className="font-bold text-slate-800">
                            {TERMS_BY_ID[s.termId]?.name ?? s.termId}
                          </span>
                          <span className="text-xs font-mono text-rose-600 font-bold tabular-nums">
                            {s.incorrect} қате / {s.attempts} әрекет
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Recent Games Table */}
              {stats.recentGames.length > 0 && (
                <div className="bg-white rounded-2xl p-5 border border-slate-200 space-y-3">
                  <h2 className="font-display font-bold text-base text-slate-900">
                    Соңғы ойындар тарихы
                  </h2>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm">
                      <thead className="text-xs font-bold text-slate-500 border-b border-slate-200">
                        <tr>
                          <th className="py-2 pr-4">Күні</th>
                          <th className="py-2 pr-4">Режим</th>
                          <th className="py-2 pr-4">Жеңімпаз</th>
                          <th className="py-2 pr-4">BioCoin</th>
                          <th className="py-2 pr-4">Айналым</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 tabular-nums">
                        {stats.recentGames.map((g) => (
                          <tr key={g.id}>
                            <td className="py-2.5 pr-4 text-slate-600">
                              {new Date(g.dateIso).toLocaleDateString('kk-KZ')}
                            </td>
                            <td className="py-2.5 pr-4 font-semibold text-slate-700">
                              {g.mode === 'learning' ? 'Үйрену режимі' : 'Еркін ойын'}
                            </td>
                            <td className="py-2.5 pr-4 font-bold text-emerald-800">
                              {g.winnerName}
                            </td>
                            <td className="py-2.5 pr-4 font-mono font-bold text-amber-700">
                              {g.winnerCoins}
                            </td>
                            <td className="py-2.5 pr-4 text-slate-600">{g.roundsPlayed}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </main>
  );
};

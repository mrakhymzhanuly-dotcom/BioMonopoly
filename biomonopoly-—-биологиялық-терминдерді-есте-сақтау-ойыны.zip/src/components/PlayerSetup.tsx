import React, { useState } from 'react';
import { ArrowLeft, Compass, Play, Sparkles, Users } from 'lucide-react';
import { STARTING_BIOCOIN } from '../game/rules';
import { AvatarId, GameMode, PlayerConfig } from '../types/game';
import { BioCoinIcon } from './BioIcon';
import { AVATAR_OPTIONS, PLAYER_COLORS, PlayerAvatar } from './PlayerAvatar';

interface PlayerSetupProps {
  initialMode: GameMode;
  onBack: () => void;
  onStartMatch: (players: PlayerConfig[], mode: GameMode, maxRounds: number) => void;
}

const DEFAULT_NAMES = ['Айша', 'Ерасыл', 'Диана', 'Нұрсұлтан'];

const DEFAULT_PLAYERS: PlayerConfig[] = [
  { name: DEFAULT_NAMES[0], avatarId: 'microscope', color: PLAYER_COLORS[0].hex, colorName: PLAYER_COLORS[0].name },
  { name: DEFAULT_NAMES[1], avatarId: 'dna', color: PLAYER_COLORS[1].hex, colorName: PLAYER_COLORS[1].name },
  { name: DEFAULT_NAMES[2], avatarId: 'leaf', color: PLAYER_COLORS[2].hex, colorName: PLAYER_COLORS[2].name },
  { name: DEFAULT_NAMES[3], avatarId: 'heart', color: PLAYER_COLORS[3].hex, colorName: PLAYER_COLORS[3].name },
];

export const PlayerSetup: React.FC<PlayerSetupProps> = ({
  initialMode,
  onBack,
  onStartMatch,
}) => {
  const [playerCount, setPlayerCount] = useState<number>(2);
  const [configs, setConfigs] = useState<PlayerConfig[]>(DEFAULT_PLAYERS);
  const [mode, setMode] = useState<GameMode>(initialMode);
  const [maxRounds, setMaxRounds] = useState<number>(8);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const updatePlayer = (index: number, patch: Partial<PlayerConfig>) => {
    setConfigs((prev) => prev.map((item, i) => (i === index ? { ...item, ...patch } : item)));
    setErrorMsg(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const activePlayers = configs.slice(0, playerCount).map((p, idx) => ({
      ...p,
      name: p.name.trim() || `${idx + 1}-ойыншы`,
    }));

    const usedColors = new Set(activePlayers.map((p) => p.color));
    if (usedColors.size < activePlayers.length) {
      setErrorMsg('Әр ойыншының түсі бірегей болуы тиіс.');
      return;
    }

    onStartMatch(activePlayers, mode, maxRounds);
  };

  return (
    <main className="min-h-screen flex items-center justify-center p-4 sm:p-8" data-testid="setup-screen">
      <div className="w-full max-w-4xl bg-[#f7f5ee] rounded-3xl shadow-2xl border-4 border-emerald-950/20 overflow-hidden">
        <div className="bg-emerald-800 px-6 py-5 text-white flex items-center justify-between gap-4">
          <button
            type="button"
            onClick={onBack}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/15 hover:bg-white/25 text-sm font-bold transition-colors cursor-pointer whitespace-nowrap"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Басты мәзір</span>
          </button>

          <h1 className="font-display font-black text-xl sm:text-2xl truncate">
            Ойыншыларды баптау
          </h1>

          <div className="hidden sm:flex items-center gap-1.5 text-xs font-bold bg-black/20 px-3 py-1.5 rounded-lg whitespace-nowrap">
            <BioCoinIcon className="w-4 h-4" />
            <span>Бастапқы: {STARTING_BIOCOIN}</span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-6 sm:p-8 space-y-6">
          {/* Player Count & Mode & Rounds */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Player Count */}
            <div className="bg-white rounded-2xl p-4 border border-slate-200 space-y-2.5">
              <div className="flex items-center gap-2 text-sm font-bold text-slate-800">
                <Users className="w-4 h-4 text-emerald-700" />
                <span>Ойыншы саны</span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {[2, 3, 4].map((count) => (
                  <button
                    key={count}
                    type="button"
                    onClick={() => setPlayerCount(count)}
                    data-testid={`player-count-${count}`}
                    className={`py-2.5 rounded-xl font-display font-bold text-sm transition-colors cursor-pointer ${
                      playerCount === count
                        ? 'bg-emerald-700 text-white shadow-sm'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {count} ойыншы
                  </button>
                ))}
              </div>
            </div>

            {/* Game Mode */}
            <div className="bg-white rounded-2xl p-4 border border-slate-200 space-y-2.5">
              <div className="flex items-center gap-2 text-sm font-bold text-slate-800">
                <Compass className="w-4 h-4 text-violet-700" />
                <span>Ойын режимі</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setMode('learning')}
                  data-testid="mode-learning"
                  className={`py-2.5 px-2 rounded-xl font-display font-bold text-xs sm:text-sm transition-colors cursor-pointer ${
                    mode === 'learning'
                      ? 'bg-violet-700 text-white shadow-sm'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  Үйрену режимі
                </button>
                <button
                  type="button"
                  onClick={() => setMode('free')}
                  data-testid="mode-free"
                  className={`py-2.5 px-2 rounded-xl font-display font-bold text-xs sm:text-sm transition-colors cursor-pointer ${
                    mode === 'free'
                      ? 'bg-emerald-700 text-white shadow-sm'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  Еркін ойын
                </button>
              </div>
            </div>

            {/* Rounds */}
            <div className="bg-white rounded-2xl p-4 border border-slate-200 space-y-2.5">
              <div className="flex items-center gap-2 text-sm font-bold text-slate-800">
                <Sparkles className="w-4 h-4 text-amber-600" />
                <span>Ойын ұзақтығы</span>
              </div>
              <div className="grid grid-cols-4 gap-1.5">
                {[
                  { val: 5, label: '5 айн.' },
                  { val: 8, label: '8 айн.' },
                  { val: 12, label: '12 айн.' },
                  { val: 0, label: 'Еркін' },
                ].map((opt) => (
                  <button
                    key={opt.val}
                    type="button"
                    onClick={() => setMaxRounds(opt.val)}
                    className={`py-2.5 px-1 rounded-xl font-display font-bold text-xs transition-colors cursor-pointer whitespace-nowrap ${
                      maxRounds === opt.val
                        ? 'bg-amber-500 text-slate-950 shadow-sm'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Mode Explanation Banner */}
          <div className="rounded-xl bg-white border border-slate-200 px-4 py-3 text-xs sm:text-sm text-slate-700">
            {mode === 'learning' ? (
              <span>
                <strong>Үйрену режимі:</strong> сұрақ алдында көмекші кеңестер мен мысалдар көрсетіледі, ал қате жауаптан кейін толық есте сақтау нұсқаулығы беріледі.
              </span>
            ) : (
              <span>
                <strong>Еркін ойын:</strong> сұрақтарға өз біліміңе сүйеніп жауап бересің, алдын ала кеңестер берілмейді.
              </span>
            )}
          </div>

          {/* Player Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {configs.slice(0, playerCount).map((player, idx) => (
              <div
                key={idx}
                className="bg-white rounded-2xl p-4 border border-slate-200 space-y-3 shadow-sm"
              >
                <div className="flex items-center gap-3">
                  <PlayerAvatar avatarId={player.avatarId} color={player.color} size="lg" />
                  <div className="flex-1 min-w-0">
                    <label
                      htmlFor={`player-name-${idx}`}
                      className="block text-xs font-bold text-slate-500 mb-1"
                    >
                      {idx + 1}-ойыншының аты
                    </label>
                    <input
                      id={`player-name-${idx}`}
                      type="text"
                      value={player.name}
                      maxLength={18}
                      onChange={(e) => updatePlayer(idx, { name: e.target.value })}
                      placeholder={`${idx + 1}-ойыншы`}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    />
                  </div>
                </div>

                {/* Avatar Picker */}
                <div>
                  <div className="text-xs font-semibold text-slate-500 mb-1.5">Таңба (Аватар)</div>
                  <div className="flex flex-wrap gap-1.5">
                    {AVATAR_OPTIONS.map((av) => (
                      <button
                        key={av.id}
                        type="button"
                        onClick={() => updatePlayer(idx, { avatarId: av.id as AvatarId })}
                        aria-label={`${idx + 1}-ойыншы аватары: ${av.label}`}
                        className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                          player.avatarId === av.id
                            ? 'bg-emerald-700 text-white'
                            : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                        }`}
                      >
                        {av.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Color Picker */}
                <div>
                  <div className="text-xs font-semibold text-slate-500 mb-1.5">Ойыншы түсі</div>
                  <div className="flex items-center gap-2">
                    {PLAYER_COLORS.map((col) => {
                      const takenByOther = configs
                        .slice(0, playerCount)
                        .some((other, oIdx) => oIdx !== idx && other.color === col.hex);
                      const selected = player.color === col.hex;
                      return (
                        <button
                          key={col.hex}
                          type="button"
                          disabled={takenByOther}
                          onClick={() =>
                            updatePlayer(idx, { color: col.hex, colorName: col.name })
                          }
                          aria-label={`${idx + 1}-ойыншы түсі: ${col.name}`}
                          className={`w-7 h-7 rounded-full border-2 transition-transform cursor-pointer disabled:opacity-25 disabled:cursor-not-allowed ${
                            selected ? 'scale-115 border-slate-900 ring-2 ring-amber-400' : 'border-white shadow'
                          }`}
                          style={{ backgroundColor: col.hex }}
                        />
                      );
                    })}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {errorMsg && (
            <div className="rounded-xl bg-rose-50 border border-rose-300 px-4 py-3 text-sm font-bold text-rose-800">
              {errorMsg}
            </div>
          )}

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              data-testid="confirm-start-btn"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-4 rounded-2xl bg-emerald-700 hover:bg-emerald-800 text-white font-display font-black text-lg shadow-[0_4px_0_#064e3b] active:translate-y-0.5 transition-all cursor-pointer whitespace-nowrap"
            >
              <Play className="w-5 h-5 fill-current" />
              <span>Ойынды бастау</span>
            </button>
          </div>
        </form>
      </div>
    </main>
  );
};

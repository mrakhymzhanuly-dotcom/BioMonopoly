import React from 'react';
import { ArrowLeft, BookOpen, Dices, HelpCircle, ShieldAlert, Trophy } from 'lucide-react';
import { BioCoinIcon } from './BioIcon';

interface RulesViewProps {
  onBack: () => void;
  onStartGame: () => void;
}

export const RulesView: React.FC<RulesViewProps> = ({ onBack, onStartGame }) => {
  return (
    <main className="min-h-screen p-4 sm:p-8 flex justify-center" data-testid="rules-screen">
      <div className="w-full max-w-4xl bg-[#f7f5ee] rounded-3xl shadow-2xl border-4 border-emerald-950/20 overflow-hidden">
        <div className="bg-emerald-800 px-6 py-5 text-white flex items-center justify-between gap-4">
          <button
            type="button"
            onClick={onBack}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/15 hover:bg-white/25 text-sm font-bold transition-colors cursor-pointer whitespace-nowrap"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Басты мәзір</span>
          </button>

          <h1 className="font-display font-black text-xl sm:text-2xl">Ойын ережелері</h1>

          <div className="w-24 hidden sm:block" />
        </div>

        <div className="p-6 sm:p-8 space-y-6">
          <div className="bg-white rounded-2xl p-5 border border-slate-200 space-y-2">
            <div className="flex items-center gap-2.5 text-emerald-800 font-display font-black text-lg">
              <Trophy className="w-5 h-5 text-amber-500" />
              <h2>Ойынның басты мақсаты</h2>
            </div>
            <p className="text-slate-700 text-sm sm:text-base leading-relaxed">
              Ойыншылар кезекпен кубик лақтырып, 36 ұяшықтан тұратын биологиялық тақта бойымен қозғалады. Әрбір биологиялық терминге тоқтағанда сұраққа жауап беріп, BioCoin жинайды. Ойын соңында ең көп BioCoin жинаған ойыншы жеңімпаз атанады!
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-white rounded-2xl p-5 border border-slate-200 space-y-2.5">
              <div className="flex items-center gap-2 font-display font-bold text-base text-slate-900">
                <Dices className="w-5 h-5 text-emerald-700" />
                <h3>1. Кубик және қозғалыс</h3>
              </div>
              <ul className="space-y-1.5 text-sm text-slate-700 list-disc pl-5">
                <li>Әр ойыншы ойынды <strong>500 BioCoin</strong> қорымен «Бастау» ұяшығынан бастайды.</li>
                <li>Өз кезегіңізде «Кубикті лақтыру» батырмасын басыңыз — екі кубик нәтижесі бойынша фишка бір ұяшықтан ретпен жылжиды.</li>
                <li>«Бастау» ұяшығынан өткенде немесе оған тоқтағанда <strong>+100 BioCoin</strong> сыйақы беріледі.</li>
              </ul>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-slate-200 space-y-2.5">
              <div className="flex items-center gap-2 font-display font-bold text-base text-slate-900">
                <BioCoinIcon className="w-5 h-5" />
                <h3>2. Термин сұрақтары</h3>
              </div>
              <ul className="space-y-1.5 text-sm text-slate-700 list-disc pl-5">
                <li>Термин ұяшығына түскенде 4 нұсқалы тест сұрағы ашылады.</li>
                <li>Дұрыс жауап берсеңіз — <strong>+100 BioCoin</strong> және ғылыми түсіндірме.</li>
                <li>Қате жауап берсеңіз — <strong>-50 BioCoin</strong> айыппұл және дұрыс жауаптың қарапайым түсіндірмесі көрсетіледі.</li>
              </ul>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-slate-200 space-y-2.5">
              <div className="flex items-center gap-2 font-display font-bold text-base text-slate-900">
                <ShieldAlert className="w-5 h-5 text-orange-600" />
                <h3>3. Арнайы ұяшықтар</h3>
              </div>
              <ul className="space-y-1.5 text-sm text-slate-700 list-disc pl-5">
                <li><strong>Қызыл аймақ:</strong> күрделі биологиялық сұрақ (+200 BioCoin сыйақы, қате болса -100 BioCoin).</li>
                <li><strong>Шанс:</strong> тосын оқиға (+100, +150, +200, -50 BioCoin немесе бонус сұрақ).</li>
                <li><strong>Түрме:</strong> арнайы сұраққа дұрыс жауап беріп немесе 100 BioCoin төлеп босап шығуға болады.</li>
                <li><strong>Демалыс:</strong> BioCoin жоғалтпай тынығатын қауіпсіз ұяшық.</li>
              </ul>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-slate-200 space-y-2.5">
              <div className="flex items-center gap-2 font-display font-bold text-base text-slate-900">
                <BookOpen className="w-5 h-5 text-violet-700" />
                <h3>4. Ойын режимдері</h3>
              </div>
              <ul className="space-y-1.5 text-sm text-slate-700 list-disc pl-5">
                <li><strong>Үйрену режимі:</strong> сұрақ алдында кеңестер, мысалдар және есте сақтау тәсілдерін көрсетеді.</li>
                <li><strong>Еркін ойын:</strong> кеңестерсіз нағыз білім сайысы ретінде өтеді.</li>
              </ul>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-emerald-50 border border-emerald-200 rounded-2xl p-5">
            <div className="flex items-center gap-3 text-emerald-950 text-sm font-medium">
              <HelpCircle className="w-5 h-5 text-emerald-700 shrink-0" />
              <span>Тақтадағы кез келген термин ұяшығын басып, оның анықтамасын қарай аласыз.</span>
            </div>
            <button
              type="button"
              onClick={onStartGame}
              className="px-6 py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-display font-bold text-sm transition-colors cursor-pointer whitespace-nowrap"
            >
              Ойынды бастау
            </button>
          </div>
        </div>
      </div>
    </main>
  );
};

import React from 'react';
import { BookOpen, Flag, Home, Volume2, VolumeX } from 'lucide-react';
import { BOARD_CELLS } from '../data/boardCells';
import { calculateAccuracy } from '../game/rules';
import { GameMode, Player } from '../types/game';
import { BioCoinIcon } from './BioIcon';
import { PlayerAvatar } from './PlayerAvatar';

interface PlayerPanelProps {
  players: Player[];
  currentPlayerIndex: number;
  currentRound: number;
  maxRounds: number;
  mode: GameMode;
  muted: boolean;
  activityLog: string[];
  onToggleMute: () => void;
  onOpenTerms: () => void;
  onFinishGame: () => void;
  onExitToMenu: () => void;
}

export const PlayerPanel: React.FC<PlayerPanelProps> = ({
  players,
  currentPlayerIndex,
  currentRound,
  maxRounds,
  mode,
  muted,
  activityLog,
  onToggleMute,
  onOpenTerms,
  onFinishGame,
  onExitToMenu,
}) => {
  return (
    <aside className="w-full lg:w-[370px] xl:w-[390px] shrink-0 flex flex-col gap-3.5">
      {/* Top Game Shell Controls */}
      <div className="bg-[#f7f5ee] rounded-2xl border-2 border-emerald-950/20 p-3.5 shadow-lg space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div className="text-xs font-bold text-emerald-950 tabular-nums">
            <span>
              {maxRounds > 0 ? `${currentRound} / ${maxRounds}-айналым` : `${currentRound}-айналым`}
            </span>
            <span className="mx-1.5 text-slate-400">·</span>
            <span className={mode === 'learning' ? 'text-violet-700' : 'text-emerald-700'}>
              {mode === 'learning' ? 'Үйрену режимі' : 'Еркін ойын'}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={onToggleMute}
              aria-label={muted ? 'Дыбысты қосу' : 'Дыбысты өшіру'}
              title={muted ? 'Дыбысты қосу' : 'Дыбысты өшіру'}
              className="w-8 h-8 rounded-lg bg-white border border-slate-200 hover:bg-slate-100 flex items-center justify-center text-slate-700 transition-colors cursor-pointer"
            >
              {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
            <button
              type="button"
              onClick={onOpenTerms}
              aria-label="Терминдер анықтамалығы"
              title="Терминдер анықтамалығы"
              className="w-8 h-8 rounded-lg bg-white border border-slate-200 hover:bg-slate-100 flex items-center justify-center text-emerald-700 transition-colors cursor-pointer"
            >
              <BookOpen className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={onExitToMenu}
              aria-label="Басты мәзірге оралу"
              title="Басты мәзір"
              className="w-8 h-8 rounded-lg bg-white border border-slate-200 hover:bg-slate-100 flex items-center justify-center text-slate-700 transition-colors cursor-pointer"
            >
              <Home className="w-4 h-4" />
            </button>
          </div>
        </div>

        <button
          type="button"
          onClick={onFinishGame}
          data-testid="end-game-btn"
          className="w-full inline-flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-amber-100 hover:bg-amber-200 border border-amber-300 text-amber-950 font-display font-bold text-xs transition-colors cursor-pointer whitespace-nowrap"
        >
          <Flag className="w-3.5 h-3.5" />
          <span>Ойынды аяқтап, жеңімпазды анықтау</span>
        </button>
      </div>

      {/* Players List */}
      <div className="bg-[#f7f5ee] rounded-2xl border-2 border-emerald-950/20 p-3.5 shadow-lg space-y-2.5">
        <h2 className="font-display font-black text-sm text-emerald-950">Ойыншылар</h2>
        <div className="space-y-2">
          {players.map((player, idx) => {
            const isCurrent = idx === currentPlayerIndex;
            const currentCell = BOARD_CELLS[player.position];
            const acc = calculateAccuracy(player.correctCount, player.incorrectCount);

            return (
              <div
                key={player.id}
                data-testid={`player-card-${player.id}`}
                className={`rounded-xl p-3 border transition-all ${
                  isCurrent
                    ? 'bg-white border-emerald-600 ring-2 ring-emerald-500/25 shadow-sm'
                    : 'bg-white/75 border-slate-200'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <PlayerAvatar avatarId={player.avatarId} color={player.color} size="md" />
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="font-display font-extrabold text-sm text-slate-900 truncate">
                          {player.name}
                        </span>
                        {isCurrent && (
                          <span className="text-[10px] font-bold text-emerald-700">· Кезегі</span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-500 truncate">
                        {currentCell?.title ?? 'Бастау'}
                        {player.inJail ? ' · Түрмеде' : ''}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-lg shrink-0">
                    <BioCoinIcon className="w-4 h-4" />
                    <span
                      data-testid={`player-balance-${player.id}`}
                      className="font-mono font-bold text-sm text-amber-900 tabular-nums"
                    >
                      {player.balance}
                    </span>
                  </div>
                </div>

                <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-600 tabular-nums">
                  <span>
                    Дұрыс: <strong className="text-emerald-700">{player.correctCount}</strong> · Қате:{' '}
                    <strong className="text-rose-600">{player.incorrectCount}</strong>
                  </span>
                  <span>
                    Дәлдік: <strong>{acc}%</strong> · Термин: <strong>{player.visitedTermIds.length}</strong>
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Activity Feed */}
      <div className="bg-[#f7f5ee] rounded-2xl border-2 border-emerald-950/20 p-3.5 shadow-lg space-y-2">
        <h2 className="font-display font-black text-sm text-emerald-950">Ойын барысы</h2>
        {activityLog.length === 0 ? (
          <p className="text-xs text-slate-500">Ойынды бастау үшін кубикті лақтырыңыз.</p>
        ) : (
          <ul className="space-y-1.5 text-xs text-slate-700 max-h-36 overflow-y-auto">
            {activityLog.map((entry, idx) => (
              <li
                key={idx}
                className="py-1 px-2 rounded-lg bg-white border border-slate-100 leading-snug"
              >
                {entry}
              </li>
            ))}
          </ul>
        )}
      </div>
    </aside>
  );
};

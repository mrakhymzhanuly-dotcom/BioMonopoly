import React from 'react';

interface BioIconProps {
  iconKey: string;
  className?: string;
}

export const BioCoinIcon: React.FC<{ className?: string }> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
    <circle cx="12" cy="12" r="10" fill="#FACC15" stroke="#A16207" strokeWidth="1.8" />
    <circle cx="12" cy="12" r="7.2" fill="#FEF08A" stroke="#CA8A04" strokeWidth="1" />
    <path
      d="M12 7.2c-2.2 0-3.8 1.5-3.8 3.6 0 2.5 2 3.8 3.8 6 1.8-2.2 3.8-3.5 3.8-6 0-2.1-1.6-3.6-3.8-3.6z"
      fill="#15803D"
    />
    <path d="M12 9v6" stroke="#FEF08A" strokeWidth="1.2" strokeLinecap="round" />
  </svg>
);

export const BioIcon: React.FC<BioIconProps> = ({ iconKey, className = 'w-6 h-6' }) => {
  switch (iconKey) {
    case 'start':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <circle cx="12" cy="12" r="9.5" fill="#FEF3C7" stroke="#D97706" strokeWidth="1.8" />
          <path d="M8 12h8M13 8l4 4-4 4" stroke="#B45309" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
        </svg>
      );
    case 'jail':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <rect x="4" y="4" width="16" height="16" rx="2.5" fill="#FFEDD5" stroke="#EA580C" strokeWidth="1.8" />
          <path d="M8.5 4v16M12 4v16M15.5 4v16" stroke="#9A3412" strokeWidth="1.8" />
          <circle cx="12" cy="12" r="2.2" fill="#EA580C" />
        </svg>
      );
    case 'rest':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <circle cx="12" cy="12" r="9.5" fill="#DCFCE7" stroke="#15803D" strokeWidth="1.8" />
          <path d="M12 18V9M12 12c-3 0-4.5-2-4.5-4.5 2.5 0 4.5 1.5 4.5 4.5zM12 13.5c3 0 4.5-2 4.5-4.5-2.5 0-4.5 1.5-4.5 4.5z" fill="#16A34A" stroke="#14532D" strokeWidth="1" strokeLinejoin="round" />
        </svg>
      );
    case 'chance':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <rect x="4" y="3" width="16" height="18" rx="3" fill="#FFEDD5" stroke="#EA580C" strokeWidth="1.8" />
          <path d="M9.8 9.2a2.4 2.4 0 1 1 3.7 2c-.9.6-1.5 1.1-1.5 2.1v.5" stroke="#C2410C" strokeWidth="2" strokeLinecap="round" fill="none" />
          <circle cx="12" cy="16.8" r="1.1" fill="#C2410C" />
        </svg>
      );
    case 'red_zone':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <path
            d="M12 2.5l7.5 3.3v5.7c0 4.9-3.2 8.9-7.5 10.2C7.7 20.4 4.5 16.4 4.5 11.5V5.8L12 2.5z"
            fill="#FFE4E6"
            stroke="#BE123C"
            strokeWidth="1.8"
            strokeLinejoin="round"
          />
          <path d="M12 7.2v6" stroke="#E11D48" strokeWidth="2.4" strokeLinecap="round" />
          <circle cx="12" cy="16.4" r="1.3" fill="#BE123C" />
        </svg>
      );
    case 'cell':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <path d="M5 7.5C5 5.6 7.5 4 12 4s7 1.6 7 3.5v9c0 1.9-2.5 3.5-7 3.5s-7-1.6-7-3.5v-9z" fill="#DDD6FE" stroke="#6D28D9" strokeWidth="1.7" />
          <circle cx="12" cy="11.5" r="3.2" fill="#8B5CF6" stroke="#4C1D95" strokeWidth="1.3" />
          <circle cx="11.3" cy="10.8" r="0.9" fill="#EDE9FE" />
          <ellipse cx="7.8" cy="15.2" rx="1.3" ry="0.7" fill="#10B981" />
          <ellipse cx="15.8" cy="15" rx="1.2" ry="0.7" fill="#F59E0B" />
        </svg>
      );
    case 'tissue':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <polygon points="8,4 14,4 16,8 14,12 8,12 6,8" fill="#BBF7D0" stroke="#15803D" strokeWidth="1.5" />
          <polygon points="14,12 20,12 22,16 20,20 14,20 12,16" fill="#86EFAC" stroke="#15803D" strokeWidth="1.5" />
          <polygon points="4,12 10,12 12,16 10,20 4,20 2,16" fill="#DCFCE7" stroke="#15803D" strokeWidth="1.5" />
          <circle cx="11" cy="8" r="1.1" fill="#166534" />
          <circle cx="17" cy="16" r="1.1" fill="#166534" />
          <circle cx="7" cy="16" r="1.1" fill="#166534" />
        </svg>
      );
    case 'organ':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <path d="M12 20C7 16.5 4.5 13 4.5 9.2 4.5 6.8 6.4 5 8.8 5c1.5 0 2.6.8 3.2 1.8C12.6 5.8 13.7 5 15.2 5c2.4 0 4.3 1.8 4.3 4.2 0 3.8-2.5 7.3-7.5 10.8z" fill="#FDA4AF" stroke="#BE123C" strokeWidth="1.7" />
          <path d="M12 8.5v7M9.5 11.5h5" stroke="#9F1239" strokeWidth="1.3" strokeLinecap="round" />
        </svg>
      );
    case 'organism':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <circle cx="12" cy="5.5" r="2.5" fill="#A7F3D0" stroke="#047857" strokeWidth="1.6" />
          <path d="M12 8.5v6.5M7.5 11.5h9M12 15l-3.5 5.5M12 15l3.5 5.5" stroke="#047857" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case 'homeostasis':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <path d="M12 4v15M6 19h12M5 9h14" stroke="#0284C7" strokeWidth="1.8" strokeLinecap="round" />
          <path d="M5 9l-2 5h4l-2-5zM19 9l-2 5h4l-2-5z" fill="#BAE6FD" stroke="#0369A1" strokeWidth="1.4" strokeLinejoin="round" />
        </svg>
      );
    case 'gene':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <rect x="4" y="8" width="16" height="8" rx="3" fill="#EDE9FE" stroke="#7C3AED" strokeWidth="1.7" />
          <path d="M8 8v8M12 8v8M16 8v8" stroke="#6D28D9" strokeWidth="1.8" />
          <circle cx="12" cy="12" r="2" fill="#F59E0B" />
        </svg>
      );
    case 'chromosome':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <path d="M7 4c1.5 4 3.5 6.5 5 8-1.5 1.5-3.5 4-5 8M17 4c-1.5 4-3.5 6.5-5 8 1.5 1.5 3.5 4 5 8" stroke="#7C3AED" strokeWidth="3.2" strokeLinecap="round" fill="none" />
          <circle cx="12" cy="12" r="2.2" fill="#F59E0B" stroke="#4C1D95" strokeWidth="1.2" />
        </svg>
      );
    case 'respiration':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <path d="M12 4v6M12 10c-2-1-6 0-7 4-.8 3.2 1.2 5.5 3.5 5.5 1.8 0 2.5-1.5 2.5-4V10zM12 10c2-1 6 0 7 4 .8 3.2-1.2 5.5-3.5 5.5-1.8 0-2.5-1.5-2.5-4V10z" fill="#BAE6FD" stroke="#0369A1" strokeWidth="1.7" strokeLinejoin="round" />
        </svg>
      );
    case 'photosynthesis':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <circle cx="7" cy="6.5" r="2.8" fill="#FACC15" stroke="#CA8A04" strokeWidth="1.3" />
          <path d="M7 21c6 0 12-4.5 12-12-7.5 0-12 4.5-12 12z" fill="#4ADE80" stroke="#15803D" strokeWidth="1.7" strokeLinejoin="round" />
          <path d="M7 21c3.5-3.5 7-7 10-10" stroke="#14532D" strokeWidth="1.4" strokeLinecap="round" />
        </svg>
      );
    case 'metabolism':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <path d="M4.5 12a7.5 7.5 0 0 1 13-5.2M19.5 12a7.5 7.5 0 0 1-13 5.2" stroke="#15803D" strokeWidth="2" strokeLinecap="round" fill="none" />
          <path d="M15.5 4.2l2.4 2.7-3.4.6zM8.5 19.8l-2.4-2.7 3.4-.6z" fill="#15803D" />
          <circle cx="12" cy="12" r="2.3" fill="#FACC15" stroke="#B45309" strokeWidth="1.3" />
        </svg>
      );
    case 'division':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <circle cx="8" cy="12" r="5" fill="#DDD6FE" stroke="#6D28D9" strokeWidth="1.6" />
          <circle cx="16" cy="12" r="5" fill="#DDD6FE" stroke="#6D28D9" strokeWidth="1.6" />
          <circle cx="7.5" cy="12" r="1.5" fill="#6D28D9" />
          <circle cx="16.5" cy="12" r="1.5" fill="#6D28D9" />
        </svg>
      );
    case 'turgor':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <rect x="4" y="5" width="16" height="14" rx="4" fill="#A7F3D0" stroke="#047857" strokeWidth="1.8" />
          <path d="M12 8.5c-1.8 2.2-2.8 3.6-2.8 5a2.8 2.8 0 0 0 5.6 0c0-1.4-1-2.8-2.8-5z" fill="#0EA5E9" stroke="#0369A1" strokeWidth="1.2" />
        </svg>
      );
    case 'mitosis':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <ellipse cx="12" cy="12" rx="9" ry="6.5" fill="#EDE9FE" stroke="#7C3AED" strokeWidth="1.7" />
          <path d="M9 9.5v5M15 9.5v5M6 12h3M15 12h3" stroke="#5B21B6" strokeWidth="1.7" strokeLinecap="round" />
        </svg>
      );
    case 'meiosis':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <circle cx="7.5" cy="7.5" r="3.6" fill="#DDD6FE" stroke="#6D28D9" strokeWidth="1.5" />
          <circle cx="16.5" cy="7.5" r="3.6" fill="#DDD6FE" stroke="#6D28D9" strokeWidth="1.5" />
          <circle cx="7.5" cy="16.5" r="3.6" fill="#DDD6FE" stroke="#6D28D9" strokeWidth="1.5" />
          <circle cx="16.5" cy="16.5" r="3.6" fill="#DDD6FE" stroke="#6D28D9" strokeWidth="1.5" />
        </svg>
      );
    case 'dna':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <path d="M7 3.5c0 4.5 10 4.5 10 8.5s-10 4-10 8.5M17 3.5c0 4.5-10 4.5-10 8.5s10 4 10 8.5" stroke="#7C3AED" strokeWidth="2.1" strokeLinecap="round" fill="none" />
          <path d="M8.5 6.5h7M9 12h6M8.5 17.5h7" stroke="#F59E0B" strokeWidth="1.6" strokeLinecap="round" />
        </svg>
      );
    case 'rna':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <path d="M8 3.5c6 3.5 6 6.5 0 10s-6 5.5 2 7" stroke="#8B5CF6" strokeWidth="2.3" strokeLinecap="round" fill="none" />
          <path d="M10.5 6.5h3.5M11.5 10h3.5M7 14.5h3.5M8.5 18h3.5" stroke="#10B981" strokeWidth="1.7" strokeLinecap="round" />
        </svg>
      );
    case 'protein':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <circle cx="6" cy="14" r="2.8" fill="#C4B5FD" stroke="#6D28D9" strokeWidth="1.4" />
          <circle cx="10.5" cy="9" r="3" fill="#A78BFA" stroke="#5B21B6" strokeWidth="1.4" />
          <circle cx="15.5" cy="13.5" r="2.8" fill="#8B5CF6" stroke="#4C1D95" strokeWidth="1.4" />
          <circle cx="18.5" cy="8.5" r="2.3" fill="#DDD6FE" stroke="#6D28D9" strokeWidth="1.4" />
        </svg>
      );
    case 'enzyme':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <path d="M12 4a8 8 0 1 0 7.5 10.7l-4.5-2.7 4.5-2.7A8 8 0 0 0 12 4z" fill="#DDD6FE" stroke="#6D28D9" strokeWidth="1.7" strokeLinejoin="round" />
          <circle cx="17.5" cy="12" r="2.2" fill="#FACC15" stroke="#B45309" strokeWidth="1.2" />
        </svg>
      );
    case 'hormone':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <circle cx="8" cy="12" r="3.8" fill="#BAE6FD" stroke="#0284C7" strokeWidth="1.7" />
          <path d="M11.8 12h7.2M16 12v3M18.5 12v2" stroke="#0284C7" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
    case 'antibody':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <path d="M12 12v8M12 12L6.5 5.5M12 12l5.5-6.5" stroke="#0284C7" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" fill="none" />
          <circle cx="6.5" cy="5.5" r="1.8" fill="#38BDF8" />
          <circle cx="17.5" cy="5.5" r="1.8" fill="#38BDF8" />
        </svg>
      );
    case 'erythrocyte':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <circle cx="12" cy="12" r="7.5" fill="#F87171" stroke="#B91C1C" strokeWidth="1.7" />
          <circle cx="12" cy="12" r="3.2" fill="#FCA5A5" stroke="#DC2626" strokeWidth="1.1" />
        </svg>
      );
    case 'leukocyte':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <path d="M12 4.5c4.2 0 7.5 3.1 7.5 7.5s-3.3 7.5-7.5 7.5-7.5-3.1-7.5-7.5 3.3-7.5 7.5-7.5z" fill="#E0F2FE" stroke="#0284C7" strokeWidth="1.7" />
          <path d="M9.5 10.5c1-1.5 4-1.5 5 0 .8 1.3-.3 3.2-2.5 3.2-2.2 0-3.3-1.9-2.5-3.2z" fill="#0284C7" />
        </svg>
      );
    case 'platelet':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <polygon points="8,6 15,5 19,11 14,18 6,16 5,10" fill="#FDE68A" stroke="#D97706" strokeWidth="1.7" strokeLinejoin="round" />
          <circle cx="10.5" cy="11" r="1" fill="#B45309" />
          <circle cx="14" cy="13.5" r="1" fill="#B45309" />
        </svg>
      );
    case 'immunity':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <path d="M12 3.5l7 3v5c0 4.6-3 8.2-7 9.5-4-1.3-7-4.9-7-9.5v-5l7-3z" fill="#BAE6FD" stroke="#0369A1" strokeWidth="1.7" strokeLinejoin="round" />
          <path d="M9.2 12l2 2 3.8-4" stroke="#0369A1" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
        </svg>
      );
    case 'vaccine':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <path d="M15.5 4.5l4 4M17.5 6.5l-9 9-3 3M6.5 13.5l4 4M10 10l4 4" stroke="#0284C7" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" fill="none" />
          <path d="M4.5 19.5l2-2" stroke="#0369A1" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
    case 'chloroplast':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <ellipse cx="12" cy="12" rx="8.5" ry="5.5" fill="#86EFAC" stroke="#15803D" strokeWidth="1.7" />
          <path d="M7.5 10.5h3M7.5 13.5h3M13.5 10.5h3M13.5 13.5h3M10.5 12h3" stroke="#14532D" strokeWidth="1.8" strokeLinecap="round" />
        </svg>
      );
    case 'bacteria':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <rect x="6" y="8" width="12" height="8" rx="4" fill="#A7F3D0" stroke="#047857" strokeWidth="1.7" />
          <path d="M18 12c2 0 2.5-1.5 4-1.5M6 10.5H4M6 13.5H4" stroke="#047857" strokeWidth="1.5" strokeLinecap="round" fill="none" />
          <circle cx="11" cy="12" r="1.4" fill="#065F46" />
        </svg>
      );
    case 'ecosystem':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <circle cx="12" cy="12" r="8.5" fill="#DCFCE7" stroke="#15803D" strokeWidth="1.7" />
          <path d="M5 14.5c3-2 5-2 7 0s4 2 7 0" stroke="#0284C7" strokeWidth="1.7" fill="none" />
          <path d="M12 13V8M12 9.5c-2 0-3-1.2-3-2.8 1.8 0 3 1 3 2.8zM12 10c2 0 3-1.2 3-2.8-1.8 0-3 1-3 2.8z" fill="#16A34A" stroke="#14532D" strokeWidth="0.9" />
        </svg>
      );
    case 'nervous_system':
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <circle cx="9" cy="12" r="3.5" fill="#BAE6FD" stroke="#0284C7" strokeWidth="1.7" />
          <path d="M12.5 12h7.5M17.5 10l2.5 2-2.5 2M6.5 9.5L4 6.5M6.5 14.5L4 17.5M9 8.5V5" stroke="#0284C7" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" fill="none" />
          <circle cx="9" cy="12" r="1.2" fill="#0369A1" />
        </svg>
      );
    default:
      return (
        <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
          <circle cx="12" cy="12" r="8" fill="#DCFCE7" stroke="#15803D" strokeWidth="1.8" />
          <circle cx="12" cy="12" r="3" fill="#15803D" />
        </svg>
      );
  }
};

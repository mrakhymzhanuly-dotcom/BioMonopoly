import React from 'react';
import { AvatarId } from '../types/game';

interface PlayerAvatarProps {
  avatarId: AvatarId;
  color: string;
  size?: 'xs' | 'sm' | 'md' | 'lg';
  className?: string;
}

export const AVATAR_OPTIONS: Array<{ id: AvatarId; label: string }> = [
  { id: 'microscope', label: 'Микроскоп' },
  { id: 'dna', label: 'ДНҚ' },
  { id: 'leaf', label: 'Жапырақ' },
  { id: 'heart', label: 'Жүрек' },
  { id: 'cell', label: 'Жасуша' },
  { id: 'brain', label: 'Ми' },
];

export const PLAYER_COLORS: Array<{ hex: string; name: string }> = [
  { hex: '#7C3AED', name: 'Күлгін' },
  { hex: '#0284C7', name: 'Көк' },
  { hex: '#EA580C', name: 'Қызғылт сары' },
  { hex: '#16A34A', name: 'Жасыл' },
  { hex: '#E11D48', name: 'Қызыл' },
  { hex: '#CA8A04', name: 'Алтын' },
];

const AvatarGlyph: React.FC<{ avatarId: AvatarId }> = ({ avatarId }) => {
  switch (avatarId) {
    case 'microscope':
      return (
        <svg viewBox="0 0 24 24" className="w-3/5 h-3/5 text-white" fill="none" stroke="currentColor" strokeWidth="2.1" strokeLinecap="round" strokeLinejoin="round">
          <path d="M6 18h8M3 22h18M14 22a7 7 0 1 0 0-14h-1M9 14h2M9 12a2 2 0 0 1-2-2V6h6v4a2 2 0 0 1-2 2Z" />
          <path d="M12 6V3a1 1 0 0 0-1-1H9a1 1 0 0 0-1 1v3" />
        </svg>
      );
    case 'dna':
      return (
        <svg viewBox="0 0 24 24" className="w-3/5 h-3/5 text-white" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
          <path d="M7 4c0 4 10 4 10 8s-10 4-10 8M17 4c0 4-10 4-10 8s10 4 10 8" />
          <path d="M8.5 7h7M9 12h6M8.5 17h7" />
        </svg>
      );
    case 'leaf':
      return (
        <svg viewBox="0 0 24 24" className="w-3/5 h-3/5 text-white" fill="none" stroke="currentColor" strokeWidth="2.1" strokeLinecap="round" strokeLinejoin="round">
          <path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z" />
          <path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12" />
        </svg>
      );
    case 'heart':
      return (
        <svg viewBox="0 0 24 24" className="w-3/5 h-3/5 text-white" fill="currentColor">
          <path d="M12 20.5C7 17 4 13.3 4 9.3 4 6.7 6.1 4.5 8.7 4.5c1.5 0 2.7.7 3.3 1.8.6-1.1 1.8-1.8 3.3-1.8 2.6 0 4.7 2.2 4.7 4.8 0 4-3 7.7-8 11.2Z" />
        </svg>
      );
    case 'cell':
      return (
        <svg viewBox="0 0 24 24" className="w-3/5 h-3/5 text-white" fill="none" stroke="currentColor" strokeWidth="2">
          <circle cx="12" cy="12" r="8" />
          <circle cx="12" cy="12" r="3" fill="currentColor" />
        </svg>
      );
    case 'brain':
      return (
        <svg viewBox="0 0 24 24" className="w-3/5 h-3/5 text-white" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z" />
          <path d="M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z" />
        </svg>
      );
  }
};

export const PlayerAvatar: React.FC<PlayerAvatarProps> = ({
  avatarId,
  color,
  size = 'md',
  className = '',
}) => {
  const sizeClass =
    size === 'xs'
      ? 'w-5 h-5 sm:w-5.5 sm:h-5.5 border-[1.5px]'
      : size === 'sm'
        ? 'w-7 h-7 border-2'
        : size === 'lg'
          ? 'w-12 h-12 border-[3px]'
          : 'w-9 h-9 border-2';

  return (
    <div
      className={`rounded-full flex items-center justify-center border-white shadow-md shrink-0 ${sizeClass} ${className}`}
      style={{ backgroundColor: color }}
      aria-hidden="true"
    >
      <AvatarGlyph avatarId={avatarId} />
    </div>
  );
};

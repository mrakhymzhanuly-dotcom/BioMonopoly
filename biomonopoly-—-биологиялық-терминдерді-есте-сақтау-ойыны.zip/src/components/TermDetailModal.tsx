import React from 'react';
import { BookOpen, Sparkles, X } from 'lucide-react';
import { CATEGORY_META } from '../data/biologyTerms';
import { BiologyTerm } from '../types/game';
import { TermIllustrationStage } from './TermIllustrationStage';

interface TermDetailModalProps {
  term: BiologyTerm;
  onClose: () => void;
}

export const TermDetailModal: React.FC<TermDetailModalProps> = ({ term, onClose }) => {
  const catMeta = CATEGORY_META[term.category];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/65 p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="term-card-title"
      data-testid="term-detail-modal"
    >
      <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-pop-in my-auto">
        <div className={`${catMeta.stripBg} px-6 py-4 text-white flex items-center justify-between gap-4`}>
          <div>
            <div className="text-xs font-semibold text-white/85">{catMeta.label}</div>
            <h2 id="term-card-title" className="font-display font-black text-2xl">
              {term.name}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Картаны жабу"
            className="w-9 h-9 rounded-lg bg-white/15 hover:bg-white/25 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4 text-slate-800">
          <TermIllustrationStage
            iconKey={term.iconKey}
            category={term.category}
            variant="modal"
          />

          <div className="space-y-1">
            <div className="text-xs font-bold text-slate-500">Анықтамасы</div>
            <p className="text-sm sm:text-base leading-relaxed font-medium text-slate-900">
              {term.definition}
            </p>
          </div>

          <div className="space-y-1 pt-3 border-t border-slate-100">
            <div className="text-xs font-bold text-slate-500">Биологиялық қызметі</div>
            <p className="text-sm leading-relaxed text-slate-700">{term.functionDesc}</p>
          </div>

          <div className="space-y-1 pt-3 border-t border-slate-100">
            <div className="text-xs font-bold text-slate-500">Мысал</div>
            <p className="text-sm leading-relaxed text-slate-700">{term.example}</p>
          </div>

          <div className="rounded-xl bg-amber-50 border border-amber-200 p-4 flex items-start gap-3">
            <Sparkles className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <div className="text-xs font-bold text-amber-900">Есте сақтау кеңесі</div>
              <p className="text-sm font-semibold text-amber-950 mt-0.5">{term.memoryTip}</p>
            </div>
          </div>

          <div className="flex items-center justify-between pt-2">
            <span className="flex items-center gap-1.5 text-xs text-slate-500">
              <BookOpen className="w-3.5 h-3.5" />
              <span>Бұл термин бойынша {term.questions.length} сұрақ бар</span>
            </span>
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-display font-bold text-sm transition-colors cursor-pointer"
            >
              Жабу
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

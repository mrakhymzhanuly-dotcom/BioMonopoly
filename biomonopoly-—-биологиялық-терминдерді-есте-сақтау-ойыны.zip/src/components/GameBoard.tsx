import React from 'react';
import { CATEGORY_META } from '../data/biologyTerms';
import { BoardCell, Player } from '../types/game';
import { DiceRoller } from './DiceRoller';
import { PlayerAvatar } from './PlayerAvatar';
import { TermIllustrationStage } from './TermIllustrationStage';

interface GameBoardProps {
  cells: BoardCell[];
  players: Player[];
  currentPlayerIndex: number;
  dice: [number, number];
  isRolling: boolean;
  isMoving: boolean;
  highlightedCellIndex: number | null;
  passedTrailIndices: number[];
  turnNotice: string | null;
  onRollDice: () => void;
  onCellClick: (cell: BoardCell) => void;
  modalOpen: boolean;
}

/**
 * Map board cell index 0..35 onto a 10x10 CSS grid (rows 1..10, cols 1..10)
 * Clockwise from Bottom-Right (row 10, col 10):
 * 0..9: bottom row (col 10 down to 1, row 10)
 * 10..17: left col (row 9 down to 2, col 1)
 * 18..27: top row (col 1 up to 10, row 1)
 * 28..35: right col (row 2 up to 9, col 10)
 */
function getGridCoords(index: number): {
  row: number;
  col: number;
  side: 'bottom' | 'left' | 'top' | 'right' | 'corner';
} {
  if (index === 0) return { row: 10, col: 10, side: 'corner' };
  if (index > 0 && index < 9) return { row: 10, col: 10 - index, side: 'bottom' };
  if (index === 9) return { row: 10, col: 1, side: 'corner' };
  if (index > 9 && index < 18) return { row: 10 - (index - 9), col: 1, side: 'left' };
  if (index === 18) return { row: 1, col: 1, side: 'corner' };
  if (index > 18 && index < 27) return { row: 1, col: 1 + (index - 18), side: 'top' };
  if (index === 27) return { row: 1, col: 10, side: 'corner' };
  return { row: 1 + (index - 27), col: 10, side: 'right' };
}

function getStripPositionClass(side: 'bottom' | 'left' | 'top' | 'right' | 'corner'): string {
  switch (side) {
    case 'bottom':
      return 'top-0 left-0 right-0 h-2';
    case 'top':
      return 'bottom-0 left-0 right-0 h-2';
    case 'left':
      return 'top-0 right-0 bottom-0 w-2';
    case 'right':
      return 'top-0 left-0 bottom-0 w-2';
    default:
      return '';
  }
}

function getSpecialCellStyle(cell: BoardCell): { bg: string; border: string; labelColor: string } {
  switch (cell.kind) {
    case 'start':
      return { bg: 'bg-amber-50', border: 'border-amber-400', labelColor: 'text-amber-900' };
    case 'jail':
      return { bg: 'bg-orange-50', border: 'border-orange-400', labelColor: 'text-orange-900' };
    case 'rest':
      return { bg: 'bg-emerald-50', border: 'border-emerald-400', labelColor: 'text-emerald-900' };
    case 'chance':
      return { bg: 'bg-orange-50', border: 'border-orange-300', labelColor: 'text-orange-900' };
    case 'red_zone':
      return { bg: 'bg-rose-50', border: 'border-rose-400', labelColor: 'text-rose-900' };
    default:
      return { bg: 'bg-white', border: 'border-stone-300', labelColor: 'text-slate-900' };
  }
}

export const GameBoard: React.FC<GameBoardProps> = ({
  cells,
  players,
  currentPlayerIndex,
  dice,
  isRolling,
  isMoving,
  highlightedCellIndex,
  passedTrailIndices,
  turnNotice,
  onRollDice,
  onCellClick,
  modalOpen,
}) => {
  const activePlayer = players[currentPlayerIndex];
  const landedCell =
    highlightedCellIndex !== null ? cells[highlightedCellIndex] : cells[activePlayer.position];

  return (
    <div className="w-full flex justify-center">
      <div
        className="relative w-full max-w-[760px] aspect-square bg-[#e9efe5] border-4 border-emerald-900/80 rounded-2xl shadow-2xl p-1.5 sm:p-2 grid gap-0.5 sm:gap-1"
        style={{
          gridTemplateColumns: '1.25fr repeat(8, 1fr) 1.25fr',
          gridTemplateRows: '1.25fr repeat(8, 1fr) 1.25fr',
        }}
        data-testid="game-board"
      >
        {/* Center area spanning rows 2..9, cols 2..9 */}
        <div
          className="col-start-2 col-end-10 row-start-2 row-end-10 rounded-xl bg-[#f7f5ee] border border-emerald-900/15 flex flex-col items-center justify-between p-3 sm:p-5 relative overflow-hidden"
        >
          {/* Subtle centerpiece emblem */}
          <div className="flex flex-col items-center text-center gap-1 z-10">
            <div className="flex items-center gap-2.5">
              <img
                src="/src/assets/images/board_center_emblem_1794893183720.jpg"
                alt="BioMonopoly эмблемасы"
                referrerPolicy="no-referrer"
                className="w-11 h-11 sm:w-14 sm:h-14 rounded-full object-cover border-2 border-emerald-700/30 shadow-sm"
              />
              <div className="text-left">
                <h2 className="font-display font-black text-lg sm:text-2xl tracking-tight text-emerald-950 leading-none">
                  BioMonopoly
                </h2>
                <p className="text-[11px] sm:text-xs font-semibold text-emerald-800/80 mt-0.5">
                  Биологиялық терминдерді есте сақтау ойыны
                </p>
              </div>
            </div>
          </div>

          {/* Active cell landing banner / Turn notice */}
          <div className="w-full max-w-[340px] z-10">
            {turnNotice ? (
              <div
                className="px-3 py-2 rounded-xl bg-emerald-800 text-white text-center text-xs sm:text-sm font-bold shadow-md animate-pop-in"
                role="status"
              >
                {turnNotice}
              </div>
            ) : (
              <div className="px-3 py-2 rounded-xl bg-white border border-stone-200 text-center shadow-sm">
                <div className="text-[11px] font-semibold text-slate-500">
                  {isMoving ? 'Ойыншы қозғалуда...' : 'Ағымдағы ұяшық'}
                </div>
                <div className="font-display font-extrabold text-sm sm:text-base text-emerald-950 truncate">
                  {landedCell?.title}
                </div>
              </div>
            )}
          </div>

          {/* Dice Roller centerpiece */}
          <div className="z-10 w-full flex justify-center">
            <DiceRoller
              dice={dice}
              isRolling={isRolling}
              disabled={isRolling || isMoving || modalOpen}
              onRoll={onRollDice}
              playerName={activePlayer.name}
              playerColor={activePlayer.color}
            />
          </div>

          {/* Decorative Red Zone & Chance Deck Previews */}
          <div className="hidden sm:flex items-center justify-between w-full gap-3 z-10">
            <div className="flex items-center gap-2 bg-rose-50 border border-rose-300 rounded-lg px-2.5 py-1.5">
              <TermIllustrationStage
                iconKey="red_zone"
                specialKind="red_zone"
                variant="board"
              />
              <div className="leading-tight">
                <div className="text-[11px] font-extrabold text-rose-900">Қызыл аймақ</div>
                <div className="text-[10px] font-semibold text-rose-700">Күрделі сұрақ</div>
              </div>
            </div>
            <div className="flex items-center gap-2 bg-orange-50 border border-orange-200 rounded-lg px-2.5 py-1.5">
              <img
                src="/src/assets/images/card_chance_cover_1794893184369.jpg"
                alt="Шанс картасы"
                referrerPolicy="no-referrer"
                className="w-8 h-6 rounded object-cover"
              />
              <span className="text-[11px] font-bold text-orange-900">Шанс оқиғасы</span>
            </div>
          </div>
        </div>

        {/* 36 Perimeter Board Cells */}
        {cells.map((cell) => {
          const { row, col, side } = getGridCoords(cell.index);
          const isCorner = side === 'corner';
          const catMeta = cell.category ? CATEGORY_META[cell.category] : null;
          const specialStyle = getSpecialCellStyle(cell);
          const isHighlighted = highlightedCellIndex === cell.index;
          const isTrail = passedTrailIndices.includes(cell.index);
          const playersHere = players.filter((p) => p.position === cell.index);

          const stripPaddingClass =
            catMeta && !isCorner
              ? side === 'bottom'
                ? 'pt-2.5 pb-1 px-0.5'
                : side === 'top'
                  ? 'pt-1 pb-2.5 px-0.5'
                  : side === 'left'
                    ? 'py-1 pl-0.5 pr-2.5'
                    : 'py-1 pl-2.5 pr-0.5'
              : 'p-1 sm:p-1.5';

          return (
            <button
              key={cell.index}
              type="button"
              onClick={() => onCellClick(cell)}
              data-testid={`board-cell-${cell.index}`}
              aria-label={`${cell.index + 1}-ұяшық: ${cell.title}`}
              style={{
                gridRow: row,
                gridColumn: col,
              }}
              className={`relative flex flex-col items-center justify-between rounded-md border text-center transition-all duration-150 cursor-pointer overflow-hidden focus-visible:outline-2 focus-visible:outline-amber-400 ${stripPaddingClass} ${
                catMeta ? `${catMeta.cardBg} ${catMeta.borderColor}` : `${specialStyle.bg} ${specialStyle.border}`
              } ${
                isHighlighted
                  ? 'ring-3 ring-amber-400 shadow-lg scale-[1.04] z-20'
                  : isTrail
                    ? 'ring-2 ring-emerald-500/80 bg-emerald-100/90 z-10'
                    : 'hover:brightness-97'
              }`}
            >
              {/* Colored Monopoly Category Strip on inner edge */}
              {catMeta && !isCorner && (
                <span
                  className={`absolute ${getStripPositionClass(side)} ${catMeta.stripBg}`}
                  aria-hidden="true"
                />
              )}

              {/* Biology Illustration with layered backdrop */}
              <div className="my-auto flex items-center justify-center z-10">
                <TermIllustrationStage
                  iconKey={cell.iconKey}
                  category={cell.category}
                  specialKind={cell.kind === 'term' ? undefined : cell.kind}
                  variant="board"
                  isCorner={isCorner}
                />
              </div>

              {/* Term / Cell Name */}
              <span
                className={`text-[7.5px] sm:text-[9px] font-extrabold leading-[1.12] tracking-tight break-words w-full z-10 ${
                  catMeta ? catMeta.textColor : specialStyle.labelColor
                }`}
              >
                {cell.title}
              </span>

              {/* Player Tokens on this cell (anchored near top so label remains readable) */}
              {playersHere.length > 0 && (
                <div className="absolute inset-x-0 top-1 flex items-start justify-center pointer-events-none z-30">
                  <div className="flex flex-wrap items-center justify-center gap-0.5 p-0.5 bg-white/90 rounded-full shadow-md border border-slate-200/80">
                    {playersHere.map((p) => {
                      const isCurrent = p.id === activePlayer.id;
                      return (
                        <div
                          key={p.id}
                          data-testid={`player-token-${p.id}`}
                        >
                          <div
                            key={isCurrent && isMoving ? `hop-${p.position}` : 'idle'}
                            className={isCurrent && isMoving ? 'animate-token-hop' : ''}
                          >
                            <PlayerAvatar
                              avatarId={p.avatarId}
                              color={p.color}
                              size="xs"
                              className={isCurrent ? 'ring-2 ring-amber-400' : ''}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};

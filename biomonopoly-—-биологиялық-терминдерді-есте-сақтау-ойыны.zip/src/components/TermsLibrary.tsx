import React, { useMemo, useState } from 'react';
import { ArrowLeft, Search } from 'lucide-react';
import { ALL_BIOLOGY_TERMS, CATEGORY_META } from '../data/biologyTerms';
import { BiologyTerm, TermCategory } from '../types/game';
import { TermDetailModal } from './TermDetailModal';
import { TermIllustrationStage } from './TermIllustrationStage';

interface TermsLibraryProps {
  onBack: () => void;
}

export const TermsLibrary: React.FC<TermsLibraryProps> = ({ onBack }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'all' | TermCategory>('all');
  const [activeTerm, setActiveTerm] = useState<BiologyTerm | null>(null);

  const filteredTerms = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return ALL_BIOLOGY_TERMS.filter((term) => {
      const matchesCat = selectedCategory === 'all' || term.category === selectedCategory;
      const matchesQuery =
        q === '' ||
        term.name.toLowerCase().includes(q) ||
        term.definition.toLowerCase().includes(q) ||
        term.shortDescription.toLowerCase().includes(q);
      return matchesCat && matchesQuery;
    });
  }, [searchQuery, selectedCategory]);

  return (
    <main className="min-h-screen p-4 sm:p-8 flex justify-center" data-testid="terms-screen">
      <div className="w-full max-w-6xl bg-[#f7f5ee] rounded-3xl shadow-2xl border-4 border-emerald-950/20 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="bg-emerald-800 px-6 py-5 text-white flex flex-wrap items-center justify-between gap-4">
          <button
            type="button"
            onClick={onBack}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/15 hover:bg-white/25 text-sm font-bold transition-colors cursor-pointer whitespace-nowrap"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Басты мәзір</span>
          </button>

          <div className="text-center sm:text-left">
            <h1 className="font-display font-black text-xl sm:text-2xl">
              Биологиялық терминдер
            </h1>
            <p className="text-xs text-emerald-100">
              7-сынып оқушыларына арналған {ALL_BIOLOGY_TERMS.length} терминнің оқу карталары
            </p>
          </div>

          <div className="text-xs font-mono font-bold bg-black/20 px-3 py-1.5 rounded-lg tabular-nums">
            {filteredTerms.length} / {ALL_BIOLOGY_TERMS.length}
          </div>
        </div>

        {/* Search and Category Filters */}
        <div className="p-6 pb-2 space-y-4">
          <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <label htmlFor="term-search-input" className="sr-only">
                Термин іздеу
              </label>
              <input
                id="term-search-input"
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Термин атауын немесе анықтамасын іздеңіз..."
                data-testid="terms-search-input"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white border border-slate-300 text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-600"
              />
            </div>

            <div className="flex flex-wrap items-center gap-1.5 p-1 bg-white border border-slate-200 rounded-xl">
              {(
                [
                  { id: 'all', label: 'Барлығы' },
                  { id: 'cell_genetics', label: 'Жасуша және генетика' },
                  { id: 'human_biology', label: 'Адам биологиясы' },
                  { id: 'plant_ecology', label: 'Өсімдіктер мен экология' },
                ] as const
              ).map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setSelectedCategory(cat.id)}
                  data-testid={`filter-${cat.id}`}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer whitespace-nowrap ${
                    selectedCategory === cat.id
                      ? 'bg-emerald-700 text-white'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Terms Grid */}
        <div className="p-6 pt-3 flex-1">
          {filteredTerms.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-10 text-center text-slate-600">
              Сұранысыңыз бойынша термин табылмады. Іздеу сөзін өзгертіп көріңіз.
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredTerms.map((term) => {
                const catMeta = CATEGORY_META[term.category];
                return (
                  <button
                    key={term.id}
                    type="button"
                    onClick={() => setActiveTerm(term)}
                    data-testid={`term-card-${term.id}`}
                    className="group bg-white rounded-2xl border border-slate-200 p-4 text-left hover:border-emerald-500 hover:shadow-md transition-all flex flex-col justify-between gap-3 cursor-pointer focus-visible:outline-2 focus-visible:outline-emerald-600"
                  >
                    <div className="space-y-3 w-full">
                      <TermIllustrationStage
                        iconKey={term.iconKey}
                        category={term.category}
                        variant="card"
                      />

                      <div>
                        <div className="text-[11px] font-bold text-slate-500">
                          {catMeta.label}
                        </div>
                        <h2 className="font-display font-black text-lg text-slate-900">
                          {term.name}
                        </h2>
                      </div>

                      <p className="text-xs sm:text-sm text-slate-600 leading-relaxed line-clamp-2">
                        {term.definition}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs w-full">
                      <span className="font-semibold text-emerald-700">Оқу картасын ашу</span>
                      <span className="text-slate-400 font-mono">{term.questions.length} сұрақ</span>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {activeTerm && (
        <TermDetailModal term={activeTerm} onClose={() => setActiveTerm(null)} />
      )}
    </main>
  );
};

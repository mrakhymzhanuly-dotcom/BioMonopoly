import React from 'react';

interface DiceRollerProps {
  dice: [number, number];
  isRolling: boolean;
  disabled: boolean;
  onRoll: () => void;
  playerName: string;
  playerColor: string;
}

const PIP_POSITIONS: Record<number, Array<[number, number]>> = {
  1: [[50, 50]],
  2: [
    [28, 28],
    [72, 72],
  ],
  3: [
    [28, 28],
    [50, 50],
    [72, 72],
  ],
  4: [
    [28, 28],
    [72, 28],
    [28, 72],
    [72, 72],
  ],
  5: [
    [28, 28],
    [72, 28],
    [50, 50],
    [28, 72],
    [72, 72],
  ],
  6: [
    [28, 24],
    [72, 24],
    [28, 50],
    [72, 50],
    [28, 76],
    [72, 76],
  ],
};

const DieFace: React.FC<{ value: number; isRolling: boolean }> = ({ value, isRolling }) => {
  const pips = PIP_POSITIONS[value] ?? PIP_POSITIONS[1];
  return (
    <div
      className={`relative w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-white border-2 border-slate-200 shadow-[0_6px_0_#cbd5e1,0_10px_18px_rgba(15,23,42,0.18)] flex items-center justify-center select-none transition-transform duration-150 ${
        isRolling ? 'animate-dice-tumble' : ''
      }`}
    >
      <svg viewBox="0 0 100 100" className="w-full h-full">
        {pips.map(([cx, cy], idx) => (
          <circle
            key={idx}
            cx={cx}
            cy={cy}
            r={value === 1 ? 12 : 9.5}
            fill={value === 1 ? '#dc2626' : '#0f172a'}
          />
        ))}
      </svg>
    </div>
  );
};

export const DiceRoller: React.FC<DiceRollerProps> = ({
  dice,
  isRolling,
  disabled,
  onRoll,
  playerName,
  playerColor,
}) => {
  const total = dice[0] + dice[1];

  return (
    <div className="flex flex-col items-center gap-3">
      <div className="flex items-center gap-3.5" aria-label={`Кубик мәндері: ${dice[0]} және ${dice[1]}`}>
        <DieFace value={dice[0]} isRolling={isRolling} />
        <DieFace value={dice[1]} isRolling={isRolling} />
      </div>

      <div className="text-xs font-semibold text-emerald-950/75 tabular-nums">
        {isRolling ? 'Кубик лақтырылуда...' : `Соңғы нәтиже: ${dice[0]} + ${dice[1]} = ${total}`}
      </div>

      <button
        type="button"
        onClick={onRoll}
        disabled={disabled}
        data-testid="roll-dice-btn"
        className="w-full max-w-[230px] px-5 py-3 rounded-xl font-display font-extrabold text-sm sm:text-base text-white shadow-[0_4px_0_rgba(0,0,0,0.22)] active:translate-y-0.5 active:shadow-[0_2px_0_rgba(0,0,0,0.22)] transition-all disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-400"
        style={{
          backgroundColor: disabled ? '#64748b' : '#15803d',
        }}
      >
        Кубикті лақтыру
      </button>

      <div className="flex items-center gap-2 text-xs font-medium text-slate-700">
        <span
          className="inline-block w-2.5 h-2.5 rounded-full shrink-0"
          style={{ backgroundColor: playerColor }}
          aria-hidden="true"
        />
        <span className="truncate max-w-[210px]">Кезек: {playerName}</span>
      </div>
    </div>
  );
};

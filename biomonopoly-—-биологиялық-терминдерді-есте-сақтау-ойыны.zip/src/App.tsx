import React, { useCallback, useEffect, useRef, useState } from 'react';
import { BOARD_CELLS } from './data/boardCells';
import { ALL_BIOLOGY_TERMS, TERMS_BY_ID } from './data/biologyTerms';
import { CHANCE_CARDS, HARD_RED_ZONE_QUESTIONS, JAIL_ESCAPE_QUESTIONS } from './data/specialCards';
import {
  JAIL_BAIL_COST,
  RED_ZONE_PENALTY,
  RED_ZONE_REWARD,
  STARTING_BIOCOIN,
  advanceTurn,
  applyCoinDelta,
  calculateAccuracy,
  calculateAnswerOutcome,
  calculateRedZoneOutcome,
  calculateStartBonus,
  computeStepPath,
  pickNextQuestionForTerm,
  pickRandomTermCell,
  rankPlayers,
  recordTermAttempt,
  recordTermVisit,
  rollTwoDice,
} from './game/rules';
import {
  ActiveSessionState,
  BiologyQuestion,
  BiologyTerm,
  BoardCell,
  ChanceCard,
  GameMode,
  LifetimeStats,
  Player,
  PlayerConfig,
  ScreenView,
  SpecialCellType,
  TermStatistic,
} from './types/game';
import { soundFX } from './utils/sound';
import {
  clearActiveSession,
  loadActiveSession,
  loadLifetimeStats,
  resetLifetimeStats,
  saveActiveSession,
  saveCompletedGameToStats,
} from './utils/storage';
import { GameBoard } from './components/GameBoard';
import { PlayerPanel } from './components/PlayerPanel';
import { QuestionModal } from './components/QuestionModal';
import { EventModal } from './components/EventModal';
import { TermDetailModal } from './components/TermDetailModal';
import { GameOverModal } from './components/GameOverModal';
import { MainMenu } from './components/MainMenu';
import { PlayerSetup } from './components/PlayerSetup';
import { TermsLibrary } from './components/TermsLibrary';
import { RulesView } from './components/RulesView';
import { StatsDashboard } from './components/StatsDashboard';
import { PLAYER_COLORS } from './components/PlayerAvatar';

interface ActiveQuestionState {
  term: BiologyTerm;
  question: BiologyQuestion;
  sourceLabel?: string;
  isJailEscape?: boolean;
  isChanceBonus?: boolean;
  isRedZone?: boolean;
}

interface ActiveEventState {
  type: SpecialCellType;
  chanceCard?: ChanceCard | null;
  passedStartBonus?: number;
}

function createInitialPlayers(configs: PlayerConfig[]): Player[] {
  return configs.map((cfg, idx) => ({
    id: `p_${idx + 1}`,
    name: cfg.name,
    avatarId: cfg.avatarId,
    color: cfg.color,
    colorName: cfg.colorName,
    balance: STARTING_BIOCOIN,
    position: 0,
    inJail: false,
    jailTurns: 0,
    correctCount: 0,
    incorrectCount: 0,
    visitedTermIds: [],
    totalBioCoinEarned: 0,
  }));
}

const AUTOSTART_PLAYERS: PlayerConfig[] = [
  { name: 'Айша', avatarId: 'microscope', color: PLAYER_COLORS[0].hex, colorName: PLAYER_COLORS[0].name },
  { name: 'Ерасыл', avatarId: 'dna', color: PLAYER_COLORS[1].hex, colorName: PLAYER_COLORS[1].name },
];

export default function App() {
  const [screen, setScreen] = useState<ScreenView>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (params.get('autostart') === '1') {
        return 'playing';
      }
    }
    return 'title';
  });
  const [setupInitialMode, setSetupInitialMode] = useState<GameMode>('learning');
  const [returnAfterTerms, setReturnAfterTerms] = useState<ScreenView>('title');

  // Active Match State
  const [players, setPlayers] = useState<Player[]>(() => createInitialPlayers(AUTOSTART_PLAYERS));
  const [currentPlayerIndex, setCurrentPlayerIndex] = useState<number>(0);
  const [currentRound, setCurrentRound] = useState<number>(1);
  const [maxRounds, setMaxRounds] = useState<number>(8);
  const [mode, setMode] = useState<GameMode>('learning');
  const [dice, setDice] = useState<[number, number]>([1, 1]);
  const [usedQuestionIds, setUsedQuestionIds] = useState<string[]>([]);
  const [termStats, setTermStats] = useState<Record<string, TermStatistic>>({});
  const [startedAtIso, setStartedAtIso] = useState<string>(() => new Date().toISOString());

  // Animation & Interaction State
  const [isRolling, setIsRolling] = useState<boolean>(false);
  const [isMoving, setIsMoving] = useState<boolean>(false);
  const [highlightedCellIndex, setHighlightedCellIndex] = useState<number | null>(null);
  const [passedTrailIndices, setPassedTrailIndices] = useState<number[]>([]);
  const [turnNotice, setTurnNotice] = useState<string | null>(null);
  const [activityLog, setActivityLog] = useState<string[]>([]);
  const [muted, setMuted] = useState<boolean>(false);

  // Active Modals
  const [activeQuestion, setActiveQuestion] = useState<ActiveQuestionState | null>(null);
  const [activeEvent, setActiveEvent] = useState<ActiveEventState | null>(null);
  const [previewTerm, setPreviewTerm] = useState<BiologyTerm | null>(null);

  // Persistence
  const [hasSavedSession, setHasSavedSession] = useState<boolean>(() => Boolean(loadActiveSession()));
  const [lifetimeStats, setLifetimeStats] = useState<LifetimeStats>(() => loadLifetimeStats());
  const [lastMatchConfigs, setLastMatchConfigs] = useState<PlayerConfig[]>(AUTOSTART_PLAYERS);

  const timersRef = useRef<number[]>([]);
  const actionLockRef = useRef<boolean>(false);

  const clearAllTimers = useCallback(() => {
    for (const id of timersRef.current) {
      window.clearTimeout(id);
      window.clearInterval(id);
    }
    timersRef.current = [];
    actionLockRef.current = false;
  }, []);

  useEffect(() => {
    return () => clearAllTimers();
  }, [clearAllTimers]);

  // Mirror state machine to document.body.dataset.state and reset scroll on screen change
  useEffect(() => {
    document.body.dataset.state = screen;
    window.scrollTo(0, 0);
  }, [screen]);

  // Save ongoing match automatically to localStorage
  useEffect(() => {
    if (screen === 'playing' && players.length >= 2) {
      const session: ActiveSessionState = {
        players,
        currentPlayerIndex,
        currentRound,
        maxRounds,
        mode,
        dice,
        usedQuestionIds,
        termStats,
        startedAtIso,
      };
      saveActiveSession(session);
      setHasSavedSession(true);
    }
  }, [screen, players, currentPlayerIndex, currentRound, maxRounds, mode, dice, usedQuestionIds, termStats, startedAtIso]);

  const appendLog = useCallback((message: string) => {
    setActivityLog((prev) => [message, ...prev].slice(0, 15));
  }, []);

  const showNotice = useCallback((text: string) => {
    setTurnNotice(text);
    const id = window.setTimeout(() => {
      setTurnNotice((curr) => (curr === text ? null : curr));
    }, 2400);
    timersRef.current.push(id);
  }, []);

  const startNewMatch = useCallback(
    (configs: PlayerConfig[], chosenMode: GameMode, chosenRounds: number) => {
      clearAllTimers();
      const freshPlayers = createInitialPlayers(configs);
      setLastMatchConfigs(configs);
      setPlayers(freshPlayers);
      setCurrentPlayerIndex(0);
      setCurrentRound(1);
      setMaxRounds(chosenRounds);
      setMode(chosenMode);
      setDice([1, 1]);
      setUsedQuestionIds([]);
      setTermStats({});
      setStartedAtIso(new Date().toISOString());
      setIsRolling(false);
      setIsMoving(false);
      setHighlightedCellIndex(0);
      setPassedTrailIndices([]);
      setTurnNotice(null);
      setActiveQuestion(null);
      setActiveEvent(null);
      setPreviewTerm(null);
      setActivityLog([
        `Ойын басталды! Режим: ${chosenMode === 'learning' ? 'Үйрену режимі' : 'Еркін ойын'}.`,
      ]);
      setScreen('playing');
    },
    [clearAllTimers]
  );

  // Enter/Space shortcut on Title Screen
  useEffect(() => {
    if (screen !== 'title') return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Enter' || e.key === ' ') {
        const tag = (e.target as HTMLElement | null)?.tagName;
        if (tag === 'BUTTON' || tag === 'INPUT') return;
        e.preventDefault();
        setSetupInitialMode('learning');
        setScreen('setup');
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [screen]);

  const finalizeGame = useCallback(
    (finalPlayers: Player[], roundsCompleted: number, finalTermStats: Record<string, TermStatistic>) => {
      clearAllTimers();
      soundFX.playFanfare();
      clearActiveSession();
      setHasSavedSession(false);

      const ranked = rankPlayers(finalPlayers);
      const winner = ranked[0];
      const totalEarned = finalPlayers.reduce((sum, p) => sum + p.totalBioCoinEarned, 0);

      const updatedStats = saveCompletedGameToStats(
        {
          id: `game_${Date.now()}`,
          dateIso: new Date().toISOString(),
          mode,
          roundsPlayed: roundsCompleted,
          winnerName: winner.name,
          winnerCoins: winner.balance,
          players: ranked.map((p) => ({
            name: p.name,
            balance: p.balance,
            correctCount: p.correctCount,
            incorrectCount: p.incorrectCount,
            accuracy: calculateAccuracy(p.correctCount, p.incorrectCount),
          })),
        },
        finalTermStats,
        totalEarned
      );
      setLifetimeStats(updatedStats);
      setActiveQuestion(null);
      setActiveEvent(null);
      setScreen('gameover');
    },
    [clearAllTimers, mode]
  );

  const proceedToNextTurn = useCallback(
    (updatedPlayers: Player[], updatedTermStats: Record<string, TermStatistic>) => {
      const turn = advanceTurn(
        updatedPlayers.length,
        currentPlayerIndex,
        currentRound,
        maxRounds
      );

      if (turn.isGameOver) {
        finalizeGame(updatedPlayers, currentRound, updatedTermStats);
        return;
      }

      setCurrentPlayerIndex(turn.nextPlayerIndex);
      setCurrentRound(turn.nextRound);
      setHighlightedCellIndex(updatedPlayers[turn.nextPlayerIndex].position);
      showNotice(`Кезек келесі ойыншыға өтті: ${updatedPlayers[turn.nextPlayerIndex].name}!`);

      // If the next player is currently in jail, prompt them immediately on their turn
      const nextPlayer = updatedPlayers[turn.nextPlayerIndex];
      if (nextPlayer.inJail) {
        const tId = window.setTimeout(() => {
          setActiveEvent({ type: 'jail' });
        }, 350);
        timersRef.current.push(tId);
      }
    },
    [currentPlayerIndex, currentRound, finalizeGame, maxRounds, showNotice]
  );

  const openTermQuestion = useCallback(
    (term: BiologyTerm, sourceLabel?: string, isChanceBonus = false) => {
      const question = pickNextQuestionForTerm(term.questions, usedQuestionIds);
      setUsedQuestionIds((prev) => [...prev, question.id]);
      setActiveQuestion({
        term,
        question,
        sourceLabel,
        isChanceBonus,
      });
    },
    [usedQuestionIds]
  );

  const triggerCellLanding = useCallback(
    (cell: BoardCell, passedStart: boolean, landedOnStart: boolean) => {
      const currentPlayer = players[currentPlayerIndex];

      if (cell.kind === 'term' && cell.termId) {
        const term = TERMS_BY_ID[cell.termId];
        if (!term) return;

        setTermStats((prev) => recordTermVisit(prev, term.id));
        setPlayers((prev) =>
          prev.map((p, i) =>
            i === currentPlayerIndex && !p.visitedTermIds.includes(term.id)
              ? { ...p, visitedTermIds: [...p.visitedTermIds, term.id] }
              : p
          )
        );
        appendLog(`${currentPlayer.name} «${term.name}» терминіне тоқтады.`);
        openTermQuestion(term);
        return;
      }

      if (cell.kind === 'red_zone') {
        const question = pickNextQuestionForTerm(HARD_RED_ZONE_QUESTIONS, usedQuestionIds);
        const term = TERMS_BY_ID[question.termId] ?? ALL_BIOLOGY_TERMS[0];
        setUsedQuestionIds((prev) => [...prev, question.id]);
        setTermStats((prev) => recordTermVisit(prev, term.id));
        appendLog(`${currentPlayer.name} «Қызыл аймақ» күрделі сұрағына тап болды!`);
        setActiveQuestion({
          term,
          question,
          sourceLabel: 'Қызыл аймақ · Күрделі сұрақ',
          isRedZone: true,
        });
        return;
      }

      if (cell.kind === 'chance') {
        const card = CHANCE_CARDS[Math.floor(Math.random() * CHANCE_CARDS.length)];
        appendLog(`${currentPlayer.name} «Шанс» ұяшығына түсті: ${card.title}.`);
        setActiveEvent({ type: 'chance', chanceCard: card });
        return;
      }

      if (cell.kind === 'jail') {
        appendLog(`${currentPlayer.name} «Түрме» ұяшығына түсті.`);
        setPlayers((prev) =>
          prev.map((p, i) => (i === currentPlayerIndex ? { ...p, inJail: true } : p))
        );
        setActiveEvent({ type: 'jail' });
        return;
      }

      if (cell.kind === 'rest') {
        appendLog(`${currentPlayer.name} «Демалыс» ұяшығында тынықты.`);
        setActiveEvent({ type: 'rest' });
        return;
      }

      if (cell.kind === 'start') {
        const bonus = calculateStartBonus(landedOnStart || passedStart);
        appendLog(`${currentPlayer.name} «Бастау» ұяшығына тоқтап +${bonus} BioCoin алды.`);
        setActiveEvent({ type: 'start', passedStartBonus: bonus });
      }
    },
    [appendLog, currentPlayerIndex, openTermQuestion, players, usedQuestionIds]
  );

  const handleRollDice = useCallback(() => {
    if (
      actionLockRef.current ||
      isRolling ||
      isMoving ||
      Boolean(activeQuestion) ||
      Boolean(activeEvent)
    ) {
      return;
    }

    const activePlayer = players[currentPlayerIndex];
    if (activePlayer.inJail) {
      setActiveEvent({ type: 'jail' });
      return;
    }

    actionLockRef.current = true;
    setIsRolling(true);
    setPassedTrailIndices([]);

    const rollAnimInterval = window.setInterval(() => {
      setDice([
        Math.floor(Math.random() * 6) + 1,
        Math.floor(Math.random() * 6) + 1,
      ]);
      soundFX.playDiceTick();
    }, 110);
    timersRef.current.push(rollAnimInterval);

    const finishRollTimer = window.setTimeout(() => {
      window.clearInterval(rollAnimInterval);
      const result = rollTwoDice();
      setDice([result.die1, result.die2]);
      setIsRolling(false);
      setIsMoving(true);

      const path = computeStepPath(activePlayer.position, result.total, BOARD_CELLS.length);
      appendLog(
        `${activePlayer.name} кубик лақтырды (${result.die1} + ${result.die2} = ${result.total}).`
      );

      let stepIdx = 0;
      const startMovingTimer = window.setTimeout(() => {
        const moveInterval = window.setInterval(() => {
          if (stepIdx < path.steps.length) {
            const nextPos = path.steps[stepIdx];
            soundFX.playStep();
            setPlayers((prev) =>
              prev.map((p, idx) => (idx === currentPlayerIndex ? { ...p, position: nextPos } : p))
            );
            setPassedTrailIndices((prev) => [...prev, nextPos]);
            setHighlightedCellIndex(nextPos);
            stepIdx += 1;
          } else {
            window.clearInterval(moveInterval);
            setIsMoving(false);
            setPassedTrailIndices([]);

            // Grant START pass bonus if passed without landing on 0
            if (path.passedStart && !path.landedOnStart) {
              const passBonus = calculateStartBonus(true);
              setPlayers((prev) =>
                prev.map((p, idx) =>
                  idx === currentPlayerIndex
                    ? {
                        ...p,
                        balance: p.balance + passBonus,
                        totalBioCoinEarned: p.totalBioCoinEarned + passBonus,
                      }
                    : p
                )
              );
              showNotice(`${activePlayer.name} «Бастау» арқылы өтті! +${passBonus} BioCoin`);
              appendLog(`${activePlayer.name} «Бастау» ұяшығынан өтіп +${passBonus} BioCoin алды.`);
            } else if (path.landedOnStart) {
              const landBonus = calculateStartBonus(true);
              setPlayers((prev) =>
                prev.map((p, idx) =>
                  idx === currentPlayerIndex
                    ? {
                        ...p,
                        balance: p.balance + landBonus,
                        totalBioCoinEarned: p.totalBioCoinEarned + landBonus,
                      }
                    : p
                )
              );
            }

            const destCell = BOARD_CELLS[path.finalPosition];
            const landingDelay = window.setTimeout(() => {
              actionLockRef.current = false;
              triggerCellLanding(destCell, path.passedStart, path.landedOnStart);
            }, 450);
            timersRef.current.push(landingDelay);
          }
        }, 380);
        timersRef.current.push(moveInterval);
      }, 320);
      timersRef.current.push(startMovingTimer);
    }, 700);
    timersRef.current.push(finishRollTimer);
  }, [
    activeEvent,
    activeQuestion,
    appendLog,
    currentPlayerIndex,
    isMoving,
    isRolling,
    players,
    showNotice,
    triggerCellLanding,
  ]);

  const handleQuestionComplete = (isCorrect: boolean) => {
    if (!activeQuestion) return;
    const { term, isJailEscape, isRedZone } = activeQuestion;

    if (isCorrect) {
      soundFX.playCorrect();
    } else {
      soundFX.playWrong();
    }

    const activePlayer = players[currentPlayerIndex];
    let updatedTermStats = termStats;

    if (isJailEscape) {
      const bonusIfCorrect = isCorrect ? 0 : 0;
      const updatedPlayers = players.map((p, i) =>
        i === currentPlayerIndex
          ? {
              ...p,
              inJail: !isCorrect,
              jailTurns: isCorrect ? 0 : p.jailTurns + 1,
              balance: p.balance + bonusIfCorrect,
              correctCount: p.correctCount + (isCorrect ? 1 : 0),
              incorrectCount: p.incorrectCount + (isCorrect ? 0 : 1),
            }
          : p
      );
      setPlayers(updatedPlayers);
      appendLog(
        isCorrect
          ? `${activePlayer.name} арнайы сұраққа дұрыс жауап беріп түрмеден босады!`
          : `${activePlayer.name} қате жауап беріп, түрмеде қалды.`
      );
      setActiveQuestion(null);
      proceedToNextTurn(updatedPlayers, updatedTermStats);
      return;
    }

    const outcome = isRedZone
      ? calculateRedZoneOutcome(isCorrect, activePlayer.balance)
      : calculateAnswerOutcome(isCorrect, activePlayer.balance);
    updatedTermStats = recordTermAttempt(termStats, term.id, isCorrect);
    setTermStats(updatedTermStats);

    const updatedPlayers = players.map((p, i) =>
      i === currentPlayerIndex
        ? {
            ...p,
            balance: outcome.newBalance,
            correctCount: p.correctCount + (isCorrect ? 1 : 0),
            incorrectCount: p.incorrectCount + (isCorrect ? 0 : 1),
            totalBioCoinEarned: p.totalBioCoinEarned + (outcome.delta > 0 ? outcome.delta : 0),
          }
        : p
    );

    setPlayers(updatedPlayers);
    appendLog(
      isRedZone
        ? isCorrect
          ? `${activePlayer.name} «Қызыл аймақ» күрделі сұрағына дұрыс жауап берді (+${outcome.delta} BioCoin).`
          : `${activePlayer.name} «Қызыл аймақ» күрделі сұрағынан қателесті (${outcome.delta} BioCoin).`
        : isCorrect
          ? `${activePlayer.name} «${term.name}» сұрағына дұрыс жауап берді (+${outcome.delta} BioCoin).`
          : `${activePlayer.name} «${term.name}» сұрағынан қателесті (${outcome.delta} BioCoin).`
    );

    setActiveQuestion(null);
    proceedToNextTurn(updatedPlayers, updatedTermStats);
  };

  const handleResolveChance = (card: ChanceCard) => {
    const activePlayer = players[currentPlayerIndex];

    if (card.effectType === 'bonus_question') {
      setActiveEvent(null);
      const randomCell = pickRandomTermCell(BOARD_CELLS);
      const term = randomCell.termId ? TERMS_BY_ID[randomCell.termId] : ALL_BIOLOGY_TERMS[0];
      openTermQuestion(term, 'Шанс · Бонус сұрақ', true);
      return;
    }

    const delta =
      card.effectType === 'add_coins' ? card.amount ?? 100 : -(card.amount ?? 50);

    if (delta > 0) {
      soundFX.playCorrect();
    } else {
      soundFX.playWrong();
    }

    const updatedPlayers = players.map((p, i) =>
      i === currentPlayerIndex
        ? {
            ...p,
            balance: applyCoinDelta(p.balance, delta),
            totalBioCoinEarned: p.totalBioCoinEarned + (delta > 0 ? delta : 0),
          }
        : p
    );

    setPlayers(updatedPlayers);
    appendLog(
      `${activePlayer.name}: «${card.title}» (${delta >= 0 ? `+${delta}` : delta} BioCoin).`
    );
    setActiveEvent(null);
    proceedToNextTurn(updatedPlayers, termStats);
  };

  const handleJailAnswerQuestion = () => {
    const q = pickNextQuestionForTerm(JAIL_ESCAPE_QUESTIONS, usedQuestionIds);
    const term = TERMS_BY_ID[q.termId] ?? ALL_BIOLOGY_TERMS[0];
    setUsedQuestionIds((prev) => [...prev, q.id]);
    setActiveEvent(null);
    setActiveQuestion({
      term,
      question: q,
      sourceLabel: 'Түрмеден босап шығу сұрағы',
      isJailEscape: true,
    });
  };

  const handleJailPayBail = () => {
    const activePlayer = players[currentPlayerIndex];
    if (activePlayer.balance < JAIL_BAIL_COST) return;

    const updatedPlayers = players.map((p, i) =>
      i === currentPlayerIndex
        ? {
            ...p,
            balance: p.balance - JAIL_BAIL_COST,
            inJail: false,
            jailTurns: 0,
          }
        : p
    );
    setPlayers(updatedPlayers);
    appendLog(
      `${activePlayer.name} ${JAIL_BAIL_COST} BioCoin төлеп түрмеден босап шықты.`
    );
    setActiveEvent(null);
    proceedToNextTurn(updatedPlayers, termStats);
  };

  const handleJailSkipTurn = () => {
    const activePlayer = players[currentPlayerIndex];
    const shouldReleaseAfterWait = activePlayer.jailTurns >= 1;
    const updatedPlayers = players.map((p, i) =>
      i === currentPlayerIndex
        ? {
            ...p,
            inJail: !shouldReleaseAfterWait,
            jailTurns: shouldReleaseAfterWait ? 0 : p.jailTurns + 1,
          }
        : p
    );
    setPlayers(updatedPlayers);
    appendLog(
      shouldReleaseAfterWait
        ? `${activePlayer.name} карантин мерзімін аяқтап босады.`
        : `${activePlayer.name} түрмеде кезек өткізді.`
    );
    setActiveEvent(null);
    proceedToNextTurn(updatedPlayers, termStats);
  };

  const handleAcknowledgeStartOrRest = () => {
    setActiveEvent(null);
    proceedToNextTurn(players, termStats);
  };

  const handleBoardCellClick = (cell: BoardCell) => {
    if (isRolling || isMoving || activeQuestion || activeEvent) return;
    if (cell.kind === 'term' && cell.termId && TERMS_BY_ID[cell.termId]) {
      setPreviewTerm(TERMS_BY_ID[cell.termId]);
    }
  };

  const handleResumeSaved = () => {
    const saved = loadActiveSession();
    if (!saved) return;
    clearAllTimers();
    setPlayers(saved.players);
    setCurrentPlayerIndex(saved.currentPlayerIndex);
    setCurrentRound(saved.currentRound);
    setMaxRounds(saved.maxRounds);
    setMode(saved.mode);
    setDice(saved.dice);
    setUsedQuestionIds(saved.usedQuestionIds);
    setTermStats(saved.termStats);
    setStartedAtIso(saved.startedAtIso);
    setHighlightedCellIndex(saved.players[saved.currentPlayerIndex]?.position ?? 0);
    setActiveQuestion(null);
    setActiveEvent(null);
    setActivityLog(['Сақталған ойын сәтті жалғастырылды.']);
    setScreen('playing');
  };

  const handleToggleMute = () => {
    const next = !muted;
    setMuted(next);
    soundFX.setMuted(next);
  };

  if (screen === 'title') {
    return (
      <MainMenu
        hasSavedSession={hasSavedSession}
        onStartGame={() => {
          setSetupInitialMode('free');
          setScreen('setup');
        }}
        onStartLearningMode={() => {
          setSetupInitialMode('learning');
          setScreen('setup');
        }}
        onResumeSaved={handleResumeSaved}
        onOpenRules={() => setScreen('rules')}
        onOpenTerms={() => {
          setReturnAfterTerms('title');
          setScreen('terms');
        }}
        onOpenResults={() => {
          setLifetimeStats(loadLifetimeStats());
          setScreen('results');
        }}
      />
    );
  }

  if (screen === 'setup') {
    return (
      <PlayerSetup
        initialMode={setupInitialMode}
        onBack={() => setScreen('title')}
        onStartMatch={startNewMatch}
      />
    );
  }

  if (screen === 'terms') {
    return <TermsLibrary onBack={() => setScreen(returnAfterTerms)} />;
  }

  if (screen === 'rules') {
    return (
      <RulesView
        onBack={() => setScreen('title')}
        onStartGame={() => {
          setSetupInitialMode('learning');
          setScreen('setup');
        }}
      />
    );
  }

  if (screen === 'results') {
    return (
      <StatsDashboard
        stats={lifetimeStats}
        onBack={() => setScreen('title')}
        onResetStats={() => setLifetimeStats(resetLifetimeStats())}
      />
    );
  }

  if (screen === 'gameover') {
    return (
      <GameOverModal
        players={players}
        roundsPlayed={currentRound}
        termStats={termStats}
        onPlayAgain={() => startNewMatch(lastMatchConfigs, mode, maxRounds)}
        onReturnToMenu={() => setScreen('title')}
      />
    );
  }

  const activePlayer = players[currentPlayerIndex];

  return (
    <div className="min-h-screen p-3 sm:p-5 lg:p-6 flex items-center justify-center" data-testid="playing-screen">
      <div className="w-full max-w-[1220px] flex flex-col lg:flex-row items-center lg:items-start justify-center gap-5">
        <div className="w-full flex-1 flex justify-center">
          <GameBoard
            cells={BOARD_CELLS}
            players={players}
            currentPlayerIndex={currentPlayerIndex}
            dice={dice}
            isRolling={isRolling}
            isMoving={isMoving}
            highlightedCellIndex={highlightedCellIndex}
            passedTrailIndices={passedTrailIndices}
            turnNotice={turnNotice}
            onRollDice={handleRollDice}
            onCellClick={handleBoardCellClick}
            modalOpen={Boolean(activeQuestion || activeEvent)}
          />
        </div>

        <PlayerPanel
          players={players}
          currentPlayerIndex={currentPlayerIndex}
          currentRound={currentRound}
          maxRounds={maxRounds}
          mode={mode}
          muted={muted}
          activityLog={activityLog}
          onToggleMute={handleToggleMute}
          onOpenTerms={() => {
            setReturnAfterTerms('playing');
            setScreen('terms');
          }}
          onFinishGame={() => finalizeGame(players, currentRound, termStats)}
          onExitToMenu={() => setScreen('title')}
        />
      </div>

      {activeQuestion && (
        <QuestionModal
          term={activeQuestion.term}
          question={activeQuestion.question}
          mode={mode}
          playerName={activePlayer.name}
          sourceLabel={activeQuestion.sourceLabel}
          isRedZone={activeQuestion.isRedZone}
          rewardAmount={activeQuestion.isJailEscape ? 0 : activeQuestion.isRedZone ? RED_ZONE_REWARD : 100}
          penaltyAmount={activeQuestion.isJailEscape ? 0 : activeQuestion.isRedZone ? RED_ZONE_PENALTY : 50}
          onComplete={handleQuestionComplete}
        />
      )}

      {activeEvent && (
        <EventModal
          eventType={activeEvent.type}
          playerName={activePlayer.name}
          playerBalance={activePlayer.balance}
          chanceCard={activeEvent.chanceCard}
          passedStartBonus={activeEvent.passedStartBonus}
          onAcknowledgeStartOrRest={handleAcknowledgeStartOrRest}
          onResolveChance={handleResolveChance}
          onJailAnswerQuestion={handleJailAnswerQuestion}
          onJailPayBail={handleJailPayBail}
          onJailSkipTurn={handleJailSkipTurn}
        />
      )}

      {previewTerm && (
        <TermDetailModal term={previewTerm} onClose={() => setPreviewTerm(null)} />
      )}
    </div>
  );
}

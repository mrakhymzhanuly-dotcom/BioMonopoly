import {
  BiologyQuestion,
  BoardCell,
  Player,
  TermStatistic,
} from '../types/game';

export const STARTING_BIOCOIN = 500;
export const START_PASS_BONUS = 100;
export const CORRECT_ANSWER_REWARD = 100;
export const INCORRECT_ANSWER_PENALTY = 50;
export const RED_ZONE_REWARD = 200;
export const RED_ZONE_PENALTY = 100;
export const JAIL_BAIL_COST = 100;

export interface DiceRollResult {
  die1: number;
  die2: number;
  total: number;
}

export interface StepPathResult {
  steps: number[];
  finalPosition: number;
  passedStart: boolean;
  landedOnStart: boolean;
}

export function rollTwoDice(rng: () => number = Math.random): DiceRollResult {
  const die1 = Math.floor(rng() * 6) + 1;
  const die2 = Math.floor(rng() * 6) + 1;
  return {
    die1,
    die2,
    total: die1 + die2,
  };
}

export function computeStepPath(
  startPosition: number,
  stepCount: number,
  boardSize: number
): StepPathResult {
  if (boardSize <= 0) {
    throw new Error('Board size must be positive');
  }
  const normalizedStart = ((startPosition % boardSize) + boardSize) % boardSize;
  const steps: number[] = [];
  let passedStart = false;

  for (let i = 1; i <= stepCount; i++) {
    const pos = (normalizedStart + i) % boardSize;
    steps.push(pos);
    if (pos === 0 && i < stepCount) {
      passedStart = true;
    }
  }

  const finalPosition = steps.length > 0 ? steps[steps.length - 1] : normalizedStart;
  const landedOnStart = stepCount > 0 && finalPosition === 0;

  return {
    steps,
    finalPosition,
    passedStart: passedStart || landedOnStart,
    landedOnStart,
  };
}

export function calculateStartBonus(passedStart: boolean): number {
  return passedStart ? START_PASS_BONUS : 0;
}

export function calculateAnswerOutcome(
  isCorrect: boolean,
  currentBalance: number
): { delta: number; newBalance: number } {
  if (isCorrect) {
    return {
      delta: CORRECT_ANSWER_REWARD,
      newBalance: currentBalance + CORRECT_ANSWER_REWARD,
    };
  }
  const actualPenalty = Math.min(currentBalance, INCORRECT_ANSWER_PENALTY);
  return {
    delta: -actualPenalty,
    newBalance: currentBalance - actualPenalty,
  };
}

export function calculateRedZoneOutcome(
  isCorrect: boolean,
  currentBalance: number
): { delta: number; newBalance: number } {
  if (isCorrect) {
    return {
      delta: RED_ZONE_REWARD,
      newBalance: currentBalance + RED_ZONE_REWARD,
    };
  }
  const actualPenalty = Math.min(currentBalance, RED_ZONE_PENALTY);
  return {
    delta: -actualPenalty,
    newBalance: currentBalance - actualPenalty,
  };
}

export function applyCoinDelta(currentBalance: number, delta: number): number {
  return Math.max(0, currentBalance + delta);
}

export function canPayBail(balance: number): boolean {
  return balance >= JAIL_BAIL_COST;
}

export function calculateAccuracy(correctCount: number, incorrectCount: number): number {
  const total = correctCount + incorrectCount;
  if (total === 0) return 0;
  return Math.round((correctCount / total) * 100);
}

export function rankPlayers(players: Player[]): Player[] {
  return [...players].sort((a, b) => {
    if (b.balance !== a.balance) {
      return b.balance - a.balance;
    }
    const accA = calculateAccuracy(a.correctCount, a.incorrectCount);
    const accB = calculateAccuracy(b.correctCount, b.incorrectCount);
    if (accB !== accA) {
      return accB - accA;
    }
    return b.correctCount - a.correctCount;
  });
}

export function pickNextQuestionForTerm(
  questions: BiologyQuestion[],
  usedQuestionIds: string[],
  _rng: () => number = Math.random
): BiologyQuestion {
  if (questions.length === 0) {
    throw new Error('Term has no questions');
  }
  const unused = questions.filter((q) => !usedQuestionIds.includes(q.id));
  if (unused.length > 0) {
    return unused[0];
  }
  // All questions for this cell have been used; pick the least recently used one
  // so consecutive landings on the same cell always receive a different question.
  let leastRecentQuestion = questions[0];
  let earliestLastUse = usedQuestionIds.lastIndexOf(questions[0].id);
  for (let i = 1; i < questions.length; i += 1) {
    const lastUse = usedQuestionIds.lastIndexOf(questions[i].id);
    if (lastUse < earliestLastUse) {
      earliestLastUse = lastUse;
      leastRecentQuestion = questions[i];
    }
  }
  return leastRecentQuestion;
}

export function pickRandomTermCell(
  cells: BoardCell[],
  rng: () => number = Math.random
): BoardCell {
  const termCells = cells.filter((c) => c.kind === 'term' && c.termId);
  const idx = Math.floor(rng() * termCells.length);
  return termCells[idx];
}

export interface TurnAdvanceResult {
  nextPlayerIndex: number;
  nextRound: number;
  isGameOver: boolean;
}

export function advanceTurn(
  playerCount: number,
  currentPlayerIndex: number,
  currentRound: number,
  maxRounds: number
): TurnAdvanceResult {
  if (playerCount <= 0) {
    throw new Error('Player count must be positive');
  }
  const nextIndex = (currentPlayerIndex + 1) % playerCount;
  const wrapped = nextIndex === 0;
  const nextRound = wrapped ? currentRound + 1 : currentRound;
  const isGameOver = maxRounds > 0 && wrapped && nextRound > maxRounds;

  return {
    nextPlayerIndex: nextIndex,
    nextRound: isGameOver ? currentRound : nextRound,
    isGameOver,
  };
}

export function recordTermVisit(
  termStats: Record<string, TermStatistic>,
  termId: string
): Record<string, TermStatistic> {
  const prev = termStats[termId] ?? {
    termId,
    visits: 0,
    attempts: 0,
    correct: 0,
    incorrect: 0,
  };
  return {
    ...termStats,
    [termId]: {
      ...prev,
      visits: prev.visits + 1,
    },
  };
}

export function recordTermAttempt(
  termStats: Record<string, TermStatistic>,
  termId: string,
  isCorrect: boolean
): Record<string, TermStatistic> {
  const prev = termStats[termId] ?? {
    termId,
    visits: 0,
    attempts: 0,
    correct: 0,
    incorrect: 0,
  };
  return {
    ...termStats,
    [termId]: {
      ...prev,
      attempts: prev.attempts + 1,
      correct: prev.correct + (isCorrect ? 1 : 0),
      incorrect: prev.incorrect + (isCorrect ? 0 : 1),
    },
  };
}

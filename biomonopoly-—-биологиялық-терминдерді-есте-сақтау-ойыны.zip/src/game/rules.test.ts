import test from 'node:test';
import assert from 'node:assert/strict';
import {
  advanceTurn,
  applyCoinDelta,
  calculateAccuracy,
  calculateAnswerOutcome,
  calculateRedZoneOutcome,
  calculateStartBonus,
  canPayBail,
  computeStepPath,
  pickNextQuestionForTerm,
  rankPlayers,
  recordTermAttempt,
  recordTermVisit,
  rollTwoDice,
} from './rules';
import { ALL_BIOLOGY_TERMS } from '../data/biologyTerms';
import { BOARD_CELLS } from '../data/boardCells';
import {
  CHANCE_CARDS,
  HARD_RED_ZONE_QUESTIONS,
  JAIL_ESCAPE_QUESTIONS,
} from '../data/specialCards';
import { Player } from '../types/game';

test('rollTwoDice returns values between 1 and 6 and valid sum', () => {
  const low = rollTwoDice(() => 0);
  assert.deepEqual(low, { die1: 1, die2: 1, total: 2 });

  const high = rollTwoDice(() => 0.9999);
  assert.deepEqual(high, { die1: 6, die2: 6, total: 12 });
});

test('computeStepPath steps sequentially and detects passing START without duplicate reward', () => {
  const normal = computeStepPath(0, 5, 36);
  assert.deepEqual(normal.steps, [1, 2, 3, 4, 5]);
  assert.equal(normal.finalPosition, 5);
  assert.equal(normal.passedStart, false);
  assert.equal(normal.landedOnStart, false);

  const passing = computeStepPath(33, 6, 36);
  assert.deepEqual(passing.steps, [34, 35, 0, 1, 2, 3]);
  assert.equal(passing.finalPosition, 3);
  assert.equal(passing.passedStart, true);
  assert.equal(passing.landedOnStart, false);
  assert.equal(calculateStartBonus(passing.passedStart), 100);

  const exactLand = computeStepPath(31, 5, 36);
  assert.deepEqual(exactLand.steps, [32, 33, 34, 35, 0]);
  assert.equal(exactLand.finalPosition, 0);
  assert.equal(exactLand.passedStart, true);
  assert.equal(exactLand.landedOnStart, true);
  // Bonus granted exactly once (+100)
  assert.equal(calculateStartBonus(exactLand.passedStart), 100);
});

test('calculateAnswerOutcome awards +100 on correct and deducts up to 50 on incorrect', () => {
  assert.deepEqual(calculateAnswerOutcome(true, 500), { delta: 100, newBalance: 600 });
  assert.deepEqual(calculateAnswerOutcome(false, 500), { delta: -50, newBalance: 450 });
  assert.deepEqual(calculateAnswerOutcome(false, 20), { delta: -20, newBalance: 0 });
  assert.deepEqual(calculateRedZoneOutcome(true, 500), { delta: 200, newBalance: 700 });
  assert.deepEqual(calculateRedZoneOutcome(false, 500), { delta: -100, newBalance: 400 });
  assert.deepEqual(calculateRedZoneOutcome(false, 60), { delta: -60, newBalance: 0 });
  assert.equal(applyCoinDelta(30, -100), 0);
  assert.equal(canPayBail(100), true);
  assert.equal(canPayBail(99), false);
});

test('advanceTurn cycles players, increments rounds, and detects end of game', () => {
  const step1 = advanceTurn(3, 0, 1, 5);
  assert.deepEqual(step1, { nextPlayerIndex: 1, nextRound: 1, isGameOver: false });

  const wrapRound = advanceTurn(3, 2, 1, 5);
  assert.deepEqual(wrapRound, { nextPlayerIndex: 0, nextRound: 2, isGameOver: false });

  const endGame = advanceTurn(3, 2, 5, 5);
  assert.deepEqual(endGame, { nextPlayerIndex: 0, nextRound: 5, isGameOver: true });
});

test('rankPlayers sorts by BioCoin descending, then accuracy descending', () => {
  const makePlayer = (id: string, balance: number, correct: number, incorrect: number): Player => ({
    id,
    name: id,
    avatarId: 'cell',
    color: '#000',
    colorName: 'Black',
    balance,
    position: 0,
    inJail: false,
    jailTurns: 0,
    correctCount: correct,
    incorrectCount: incorrect,
    visitedTermIds: [],
    totalBioCoinEarned: 0,
  });

  const ranked = rankPlayers([
    makePlayer('A', 600, 2, 2), // 50%
    makePlayer('B', 700, 3, 1), // 75%
    makePlayer('C', 600, 4, 0), // 100%
  ]);
  assert.deepEqual(
    ranked.map((p) => p.id),
    ['B', 'C', 'A']
  );
  assert.equal(calculateAccuracy(3, 1), 75);
  assert.equal(calculateAccuracy(0, 0), 0);
});

test('pickNextQuestionForTerm keeps first question fixed and changes only on repeat landings', () => {
  const term = ALL_BIOLOGY_TERMS[0];
  // First landing on this cell always gets the primary question (index 0)
  const firstPick = pickNextQuestionForTerm(term.questions, []);
  assert.equal(firstPick.id, term.questions[0].id);

  // Second landing on the same cell changes to index 1
  const secondPick = pickNextQuestionForTerm(term.questions, [term.questions[0].id]);
  assert.equal(secondPick.id, term.questions[1].id);

  // Fifth landing gets the remaining unused question (index 4)
  const firstFour = term.questions.slice(0, 4).map((q) => q.id);
  const picked = pickNextQuestionForTerm(term.questions, firstFour);
  assert.equal(picked.id, term.questions[4].id);

  // After all 5 are used, rotates to least recently used (index 0, not index 4)
  const allFive = term.questions.map((q) => q.id);
  const rotated = pickNextQuestionForTerm(term.questions, allFive);
  assert.equal(rotated.id, term.questions[0].id);
});

test('recordTermVisit and recordTermAttempt accumulate stats accurately', () => {
  let stats = recordTermVisit({}, 'cell');
  stats = recordTermAttempt(stats, 'cell', true);
  stats = recordTermAttempt(stats, 'cell', false);
  assert.deepEqual(stats.cell, {
    termId: 'cell',
    visits: 1,
    attempts: 2,
    correct: 1,
    incorrect: 1,
  });
});

test('board and biology data integrity: 36 cells, all 29 terms and Red Zone questions valid', () => {
  assert.equal(BOARD_CELLS.length, 36);
  assert.equal(ALL_BIOLOGY_TERMS.length, 29);

  const redZoneCells = BOARD_CELLS.filter((c) => c.kind === 'red_zone');
  assert.equal(redZoneCells.length, 2);
  assert.ok(redZoneCells.every((c) => c.title === 'Қызыл аймақ'));

  for (const term of ALL_BIOLOGY_TERMS) {
    assert.ok(term.questions.length >= 5, `${term.id} must have >= 5 questions`);
    for (const q of term.questions) {
      assert.equal(q.options.length, 4, `${q.id} must have 4 options`);
      assert.ok(q.correctIndex >= 0 && q.correctIndex <= 3, `${q.id} valid correctIndex`);
    }
  }

  assert.ok(HARD_RED_ZONE_QUESTIONS.length >= 8);
  for (const q of HARD_RED_ZONE_QUESTIONS) {
    assert.equal(q.options.length, 4, `${q.id} must have 4 options`);
    assert.ok(q.correctIndex >= 0 && q.correctIndex <= 3, `${q.id} valid correctIndex`);
  }

  assert.ok(CHANCE_CARDS.length >= 5);
  assert.ok(JAIL_ESCAPE_QUESTIONS.length >= 5);

  const allQuestions = [
    ...ALL_BIOLOGY_TERMS.flatMap((t) => t.questions),
    ...JAIL_ESCAPE_QUESTIONS,
    ...HARD_RED_ZONE_QUESTIONS,
  ];
  const counts = [0, 0, 0, 0];
  for (const q of allQuestions) {
    counts[q.correctIndex] += 1;
  }
  for (let i = 0; i < 4; i += 1) {
    assert.ok(
      counts[i] >= 35 && counts[i] <= 46,
      `Option index ${i} count (${counts[i]}) should be balanced around 25%`
    );
  }
  for (const term of ALL_BIOLOGY_TERMS) {
    const distinct = new Set(term.questions.map((q) => q.correctIndex));
    assert.equal(distinct.size, 4, `${term.id} must use all 4 answer positions (A, B, C, D)`);
  }
});

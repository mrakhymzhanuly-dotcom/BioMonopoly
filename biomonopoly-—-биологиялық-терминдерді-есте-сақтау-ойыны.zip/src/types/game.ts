export type ScreenView =
  | 'title'
  | 'setup'
  | 'playing'
  | 'terms'
  | 'rules'
  | 'results'
  | 'gameover';

export type GameMode = 'learning' | 'free';

export type TermCategory = 'cell_genetics' | 'human_biology' | 'plant_ecology';

export type SpecialCellType = 'start' | 'jail' | 'rest' | 'chance' | 'red_zone';

export type BoardCellKind = 'term' | SpecialCellType;

export interface BiologyQuestion {
  id: string;
  termId: string;
  question: string;
  options: [string, string, string, string];
  correctIndex: 0 | 1 | 2 | 3;
  explanation: string;
  questionType: 'definition' | 'function' | 'structure' | 'significance' | 'example';
}

export interface BiologyTerm {
  id: string;
  name: string;
  category: TermCategory;
  shortDescription: string;
  definition: string;
  functionDesc: string;
  example: string;
  memoryTip: string;
  hint: string;
  iconKey: string;
  questions: BiologyQuestion[];
}

export interface BoardCell {
  index: number;
  kind: BoardCellKind;
  title: string;
  termId?: string;
  category?: TermCategory;
  iconKey: string;
  subtitle?: string;
}

export type ChanceEffectType = 'add_coins' | 'remove_coins' | 'bonus_question';

export interface ChanceCard {
  id: string;
  title: string;
  description: string;
  effectType: ChanceEffectType;
  amount?: number;
}

export type AvatarId = 'microscope' | 'dna' | 'leaf' | 'heart' | 'cell' | 'brain';

export interface PlayerConfig {
  name: string;
  avatarId: AvatarId;
  color: string;
  colorName: string;
}

export interface Player {
  id: string;
  name: string;
  avatarId: AvatarId;
  color: string;
  colorName: string;
  balance: number;
  position: number;
  inJail: boolean;
  jailTurns: number;
  correctCount: number;
  incorrectCount: number;
  visitedTermIds: string[];
  totalBioCoinEarned: number;
}

export interface TermStatistic {
  termId: string;
  visits: number;
  attempts: number;
  correct: number;
  incorrect: number;
}

export interface SavedGameRecord {
  id: string;
  dateIso: string;
  mode: GameMode;
  roundsPlayed: number;
  winnerName: string;
  winnerCoins: number;
  players: Array<{
    name: string;
    balance: number;
    correctCount: number;
    incorrectCount: number;
    accuracy: number;
  }>;
}

export interface LifetimeStats {
  totalGames: number;
  totalQuestionsAnswered: number;
  totalCorrect: number;
  totalIncorrect: number;
  totalBioCoinEarned: number;
  termStats: Record<string, TermStatistic>;
  recentGames: SavedGameRecord[];
}

export interface ActiveSessionState {
  players: Player[];
  currentPlayerIndex: number;
  currentRound: number;
  maxRounds: number;
  mode: GameMode;
  dice: [number, number];
  usedQuestionIds: string[];
  termStats: Record<string, TermStatistic>;
  startedAtIso: string;
}
